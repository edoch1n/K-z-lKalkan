import {
  boolean,
  datetime,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable(
  "users",
  {
    id: int("id").autoincrement().primaryKey(),
    openId: varchar("openId", { length: 64 }).notNull().unique(),
    name: text("name"),
    email: varchar("email", { length: 320 }),
    loginMethod: varchar("loginMethod", { length: 64 }),
    role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
    status: mysqlEnum("status", ["active", "warned", "muted", "suspended", "banned"]).default("active").notNull(),
    username: varchar("username", { length: 32 }).unique(),
    displayName: varchar("displayName", { length: 80 }),
    bio: text("bio"),
    avatarUrl: text("avatarUrl"),
    coverUrl: text("coverUrl"),
    customTitle: varchar("customTitle", { length: 80 }),
    language: varchar("language", { length: 8 }).default("tr").notNull(),
    lastActiveAt: timestamp("lastActiveAt").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  },
  (table) => ({ statusIdx: index("users_status_idx").on(table.status), activityIdx: index("users_activity_idx").on(table.lastActiveAt) }),
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const profiles = mysqlTable("profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }).unique(),
  socialLinks: text("socialLinks"),
  privacy: mysqlEnum("privacy", ["public", "members", "private"]).default("public").notNull(),
  showOnline: boolean("showOnline").default(true).notNull(),
  postCount: int("postCount").default(0).notNull(),
  threadCount: int("threadCount").default(0).notNull(),
  reactionCount: int("reactionCount").default(0).notNull(),
  visitCount: int("visitCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const storageObjects = mysqlTable(
  "storage_objects",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerId: int("ownerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    objectKey: varchar("objectKey", { length: 360 }).notNull().unique(),
    url: text("url").notNull(),
    filename: varchar("filename", { length: 180 }).notNull(),
    mimeType: varchar("mimeType", { length: 120 }).notNull(),
    sizeBytes: int("sizeBytes").notNull(),
    purpose: mysqlEnum("purpose", ["avatar", "cover", "wiki_attachment", "ctf_attachment"]).notNull(),
    visibility: mysqlEnum("visibility", ["private", "members", "public"]).default("private").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ ownerIdx: index("storage_owner_idx").on(table.ownerId, table.purpose), purposeIdx: index("storage_purpose_idx").on(table.purpose, table.createdAt) }),
);

export const roles = mysqlTable("roles", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 80 }).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const permissions = mysqlTable("permissions", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 80 }).notNull().unique(),
  label: varchar("label", { length: 120 }).notNull(),
});

export const rolePermissions = mysqlTable(
  "role_permissions",
  {
    id: int("id").autoincrement().primaryKey(),
    roleId: int("roleId").notNull().references(() => roles.id, { onDelete: "cascade" }),
    permissionId: int("permissionId").notNull().references(() => permissions.id, { onDelete: "cascade" }),
  },
  (table) => ({ unique: uniqueIndex("role_permission_unique").on(table.roleId, table.permissionId) }),
);

export const userRoles = mysqlTable(
  "user_roles",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    roleId: int("roleId").notNull().references(() => roles.id, { onDelete: "cascade" }),
    assignedBy: int("assignedBy").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ unique: uniqueIndex("user_role_unique").on(table.userId, table.roleId) }),
);

export const ranks = mysqlTable(
  "ranks",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 80 }).notNull(),
    slug: varchar("slug", { length: 100 }).notNull().unique(),
    color: varchar("color", { length: 16 }).default("#7dd3fc").notNull(),
    icon: varchar("icon", { length: 40 }).default("shield").notNull(),
    minPosts: int("minPosts").default(0).notNull(),
    sortOrder: int("sortOrder").default(0).notNull(),
    team: mysqlEnum("team", ["general", "blue", "red", "moderation", "administration"]).default("general").notNull(),
    isActive: boolean("isActive").default(true).notNull(),
  },
  (table) => ({ orderIdx: index("ranks_order_idx").on(table.sortOrder) }),
);

export const userRanks = mysqlTable(
  "user_ranks",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    rankId: int("rankId").notNull().references(() => ranks.id, { onDelete: "cascade" }),
    assignedBy: int("assignedBy").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ unique: uniqueIndex("user_rank_unique").on(table.userId, table.rankId) }),
);

export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 140 }).notNull().unique(),
  description: text("description"),
  sortOrder: int("sortOrder").default(0).notNull(),
  isVisible: boolean("isVisible").default(true).notNull(),
});

export const forums = mysqlTable(
  "forums",
  {
    id: int("id").autoincrement().primaryKey(),
    categoryId: int("categoryId").notNull().references(() => categories.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 120 }).notNull(),
    slug: varchar("slug", { length: 140 }).notNull().unique(),
    description: text("description"),
    icon: varchar("icon", { length: 40 }).default("message-square").notNull(),
    sortOrder: int("sortOrder").default(0).notNull(),
    isVisible: boolean("isVisible").default(true).notNull(),
    threadCount: int("threadCount").default(0).notNull(),
    postCount: int("postCount").default(0).notNull(),
    lastPostAt: timestamp("lastPostAt"),
  },
  (table) => ({ categoryIdx: index("forums_category_idx").on(table.categoryId), orderIdx: index("forums_order_idx").on(table.sortOrder) }),
);

export const threads = mysqlTable(
  "threads",
  {
    id: int("id").autoincrement().primaryKey(),
    forumId: int("forumId").notNull().references(() => forums.id, { onDelete: "cascade" }),
    authorId: int("authorId").notNull().references(() => users.id, { onDelete: "restrict" }),
    title: varchar("title", { length: 180 }).notNull(),
    slug: varchar("slug", { length: 220 }).notNull().unique(),
    excerpt: text("excerpt"),
    status: mysqlEnum("status", ["open", "locked", "archived"]).default("open").notNull(),
    isPinned: boolean("isPinned").default(false).notNull(),
    isAnnouncement: boolean("isAnnouncement").default(false).notNull(),
    viewCount: int("viewCount").default(0).notNull(),
    replyCount: int("replyCount").default(0).notNull(),
    lastPostAt: timestamp("lastPostAt").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({ forumIdx: index("threads_forum_idx").on(table.forumId, table.lastPostAt), authorIdx: index("threads_author_idx").on(table.authorId), statusIdx: index("threads_status_idx").on(table.status) }),
);

export const posts = mysqlTable(
  "posts",
  {
    id: int("id").autoincrement().primaryKey(),
    threadId: int("threadId").notNull().references(() => threads.id, { onDelete: "cascade" }),
    authorId: int("authorId").notNull().references(() => users.id, { onDelete: "restrict" }),
    parentPostId: int("parentPostId"),
    body: text("body").notNull(),
    bodyHtml: text("bodyHtml"),
    isDeleted: boolean("isDeleted").default(false).notNull(),
    isEdited: boolean("isEdited").default(false).notNull(),
    editedAt: timestamp("editedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({ threadIdx: index("posts_thread_idx").on(table.threadId, table.createdAt), authorIdx: index("posts_author_idx").on(table.authorId) }),
);

export const tags = mysqlTable("tags", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 40 }).notNull().unique(),
  slug: varchar("slug", { length: 60 }).notNull().unique(),
});

export const threadTags = mysqlTable(
  "thread_tags",
  {
    id: int("id").autoincrement().primaryKey(),
    threadId: int("threadId").notNull().references(() => threads.id, { onDelete: "cascade" }),
    tagId: int("tagId").notNull().references(() => tags.id, { onDelete: "cascade" }),
  },
  (table) => ({ unique: uniqueIndex("thread_tag_unique").on(table.threadId, table.tagId) }),
);

export const reactions = mysqlTable(
  "reactions",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    targetType: mysqlEnum("targetType", ["post", "thread", "wiki"]).notNull(),
    targetId: int("targetId").notNull(),
    kind: varchar("kind", { length: 24 }).default("like").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ unique: uniqueIndex("reaction_target_unique").on(table.userId, table.targetType, table.targetId), targetIdx: index("reaction_target_idx").on(table.targetType, table.targetId) }),
);

export const mentions = mysqlTable("mentions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  postId: int("postId").notNull().references(() => posts.id, { onDelete: "cascade" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const threadReads = mysqlTable(
  "thread_reads",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    threadId: int("threadId").notNull().references(() => threads.id, { onDelete: "cascade" }),
    lastReadAt: timestamp("lastReadAt").defaultNow().notNull(),
  },
  (table) => ({ unique: uniqueIndex("thread_read_unique").on(table.userId, table.threadId) }),
);

export const notifications = mysqlTable(
  "notifications",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    actorId: int("actorId").references(() => users.id, { onDelete: "set null" }),
    type: mysqlEnum("type", ["reply", "mention", "quote", "reaction", "message", "rank", "achievement", "announcement", "system", "moderation"]).notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    body: text("body"),
    href: varchar("href", { length: 300 }),
    isRead: boolean("isRead").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ userReadIdx: index("notifications_user_read_idx").on(table.userId, table.isRead, table.createdAt) }),
);

export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const conversationMembers = mysqlTable(
  "conversation_members",
  {
    id: int("id").autoincrement().primaryKey(),
    conversationId: int("conversationId").notNull().references(() => conversations.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    lastReadAt: timestamp("lastReadAt"),
  },
  (table) => ({ unique: uniqueIndex("conversation_member_unique").on(table.conversationId, table.userId) }),
);

export const messages = mysqlTable(
  "messages",
  {
    id: int("id").autoincrement().primaryKey(),
    conversationId: int("conversationId").notNull().references(() => conversations.id, { onDelete: "cascade" }),
    senderId: int("senderId").notNull().references(() => users.id, { onDelete: "restrict" }),
    body: text("body").notNull(),
    isDeleted: boolean("isDeleted").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ conversationIdx: index("messages_conversation_idx").on(table.conversationId, table.createdAt) }),
);

export const blocks = mysqlTable(
  "blocks",
  {
    id: int("id").autoincrement().primaryKey(),
    blockerId: int("blockerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    blockedId: int("blockedId").notNull().references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ unique: uniqueIndex("block_unique").on(table.blockerId, table.blockedId) }),
);

export const reports = mysqlTable(
  "reports",
  {
    id: int("id").autoincrement().primaryKey(),
    reporterId: int("reporterId").notNull().references(() => users.id, { onDelete: "restrict" }),
    targetType: mysqlEnum("targetType", ["post", "thread", "profile", "message"]).notNull(),
    targetId: int("targetId").notNull(),
    category: mysqlEnum("category", ["spam", "harassment", "inappropriate", "rules", "other"]).notNull(),
    description: text("description"),
    state: mysqlEnum("state", ["pending", "in_review", "resolved", "rejected"]).default("pending").notNull(),
    moderatorNotes: text("moderatorNotes"),
    reviewedBy: int("reviewedBy").references(() => users.id, { onDelete: "set null" }),
    reviewedAt: timestamp("reviewedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ stateIdx: index("reports_state_idx").on(table.state, table.createdAt), targetIdx: index("reports_target_idx").on(table.targetType, table.targetId) }),
);

export const moderationLogs = mysqlTable(
  "moderation_logs",
  {
    id: int("id").autoincrement().primaryKey(),
    moderatorId: int("moderatorId").notNull().references(() => users.id, { onDelete: "restrict" }),
    action: varchar("action", { length: 80 }).notNull(),
    targetType: varchar("targetType", { length: 40 }).notNull(),
    targetId: int("targetId").notNull(),
    reason: text("reason"),
    metadata: text("metadata"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ targetIdx: index("moderation_target_idx").on(table.targetType, table.targetId), createdIdx: index("moderation_created_idx").on(table.createdAt) }),
);

export const achievements = mysqlTable("achievements", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 80 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  description: text("description").notNull(),
  icon: varchar("icon", { length: 40 }).default("award").notNull(),
  requirementType: varchar("requirementType", { length: 40 }).notNull(),
  requirementValue: int("requirementValue").default(1).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
});

export const userAchievements = mysqlTable(
  "user_achievements",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    achievementId: int("achievementId").notNull().references(() => achievements.id, { onDelete: "cascade" }),
    progress: int("progress").default(0).notNull(),
    unlockedAt: timestamp("unlockedAt"),
  },
  (table) => ({ unique: uniqueIndex("user_achievement_unique").on(table.userId, table.achievementId) }),
);

export const announcements = mysqlTable(
  "announcements",
  {
    id: int("id").autoincrement().primaryKey(),
    authorId: int("authorId").notNull().references(() => users.id, { onDelete: "restrict" }),
    title: varchar("title", { length: 180 }).notNull(),
    content: text("content").notNull(),
    priority: mysqlEnum("priority", ["normal", "high", "critical"]).default("normal").notNull(),
    visibility: mysqlEnum("visibility", ["public", "members", "staff"]).default("public").notNull(),
    expiresAt: timestamp("expiresAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ visibleIdx: index("announcements_visible_idx").on(table.visibility, table.createdAt) }),
);

export const events = mysqlTable(
  "events",
  {
    id: int("id").autoincrement().primaryKey(),
    organizerId: int("organizerId").notNull().references(() => users.id, { onDelete: "restrict" }),
    title: varchar("title", { length: 180 }).notNull(),
    description: text("description").notNull(),
    startsAt: datetime("startsAt").notNull(),
    endsAt: datetime("endsAt").notNull(),
    location: varchar("location", { length: 300 }),
    link: varchar("link", { length: 500 }),
    status: mysqlEnum("status", ["draft", "published", "cancelled", "completed"]).default("draft").notNull(),
    participantCount: int("participantCount").default(0).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ eventIdx: index("events_status_start_idx").on(table.status, table.startsAt) }),
);

export const eventParticipants = mysqlTable(
  "event_participants",
  {
    id: int("id").autoincrement().primaryKey(),
    eventId: int("eventId").notNull().references(() => events.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    joinedAt: timestamp("joinedAt").defaultNow().notNull(),
  },
  (table) => ({ unique: uniqueIndex("event_participant_unique").on(table.eventId, table.userId) }),
);

export const wikiCategories = mysqlTable("wiki_categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 140 }).notNull().unique(),
});

export const wikiArticles = mysqlTable(
  "wiki_articles",
  {
    id: int("id").autoincrement().primaryKey(),
    categoryId: int("categoryId").notNull().references(() => wikiCategories.id, { onDelete: "restrict" }),
    authorId: int("authorId").notNull().references(() => users.id, { onDelete: "restrict" }),
    title: varchar("title", { length: 200 }).notNull(),
    slug: varchar("slug", { length: 220 }).notNull().unique(),
    summary: text("summary"),
    content: text("content").notNull(),
    status: mysqlEnum("status", ["draft", "review", "published", "archived"]).default("draft").notNull(),
    revision: int("revision").default(1).notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ searchIdx: index("wiki_status_updated_idx").on(table.status, table.updatedAt), categoryIdx: index("wiki_category_idx").on(table.categoryId) }),
);

export const wikiRevisions = mysqlTable(
  "wiki_revisions",
  {
    id: int("id").autoincrement().primaryKey(),
    articleId: int("articleId").notNull().references(() => wikiArticles.id, { onDelete: "cascade" }),
    editorId: int("editorId").notNull().references(() => users.id, { onDelete: "restrict" }),
    revision: int("revision").notNull(),
    title: varchar("title", { length: 200 }).notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ articleIdx: index("wiki_revision_article_idx").on(table.articleId, table.revision) }),
);

export const ctfChallenges = mysqlTable(
  "ctf_challenges",
  {
    id: int("id").autoincrement().primaryKey(),
    authorId: int("authorId").notNull().references(() => users.id, { onDelete: "restrict" }),
    title: varchar("title", { length: 180 }).notNull(),
    slug: varchar("slug", { length: 220 }).notNull().unique(),
    description: text("description").notNull(),
    category: mysqlEnum("category", ["web", "crypto", "forensics", "reverse", "osint", "misc", "programming"]).notNull(),
    difficulty: mysqlEnum("difficulty", ["easy", "medium", "hard", "expert"]).default("medium").notNull(),
    points: int("points").default(100).notNull(),
    hints: text("hints"),
    flagHash: varchar("flagHash", { length: 128 }).notNull(),
    attachmentKey: varchar("attachmentKey", { length: 300 }),
    status: mysqlEnum("status", ["draft", "published", "closed"]).default("draft").notNull(),
    solveCount: int("solveCount").default(0).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ statusIdx: index("ctf_status_idx").on(table.status, table.category), scoreIdx: index("ctf_score_idx").on(table.points) }),
);

export const ctfSubmissions = mysqlTable(
  "ctf_submissions",
  {
    id: int("id").autoincrement().primaryKey(),
    challengeId: int("challengeId").notNull().references(() => ctfChallenges.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    answerHash: varchar("answerHash", { length: 128 }).notNull(),
    isCorrect: boolean("isCorrect").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ userChallengeIdx: index("ctf_submission_user_challenge_idx").on(table.userId, table.challengeId, table.createdAt) }),
);

export const ctfWriteups = mysqlTable("ctf_writeups", {
  id: int("id").autoincrement().primaryKey(),
  challengeId: int("challengeId").notNull().references(() => ctfChallenges.id, { onDelete: "cascade" }),
  authorId: int("authorId").notNull().references(() => users.id, { onDelete: "restrict" }),
  title: varchar("title", { length: 180 }).notNull(),
  content: text("content").notNull(),
  status: mysqlEnum("status", ["draft", "published"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value").notNull(),
  updatedBy: int("updatedBy").references(() => users.id, { onDelete: "set null" }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const auditLogs = mysqlTable(
  "audit_logs",
  {
    id: int("id").autoincrement().primaryKey(),
    actorId: int("actorId").references(() => users.id, { onDelete: "set null" }),
    action: varchar("action", { length: 100 }).notNull(),
    targetType: varchar("targetType", { length: 40 }).notNull(),
    targetId: int("targetId"),
    metadata: text("metadata"),
    previousHash: varchar("previousHash", { length: 128 }),
    recordHash: varchar("recordHash", { length: 128 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ createdIdx: index("audit_created_idx").on(table.createdAt), actorIdx: index("audit_actor_idx").on(table.actorId) }),
);


export const forumModerators = mysqlTable(
  "forum_moderators",
  {
    id: int("id").autoincrement().primaryKey(),
    forumId: int("forumId").notNull().references(() => forums.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    assignedBy: int("assignedBy").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({ unique: uniqueIndex("forum_moderator_unique").on(table.forumId, table.userId), userIdx: index("forum_moderator_user_idx").on(table.userId) }),
);

export const forumPermissions = mysqlTable(
  "forum_permissions",
  {
    id: int("id").autoincrement().primaryKey(),
    forumId: int("forumId").notNull().references(() => forums.id, { onDelete: "cascade" }),
    permissionId: int("permissionId").notNull().references(() => permissions.id, { onDelete: "cascade" }),
    enabled: boolean("enabled").default(true).notNull(),
  },
  (table) => ({ unique: uniqueIndex("forum_permission_unique").on(table.forumId, table.permissionId) }),
);
