CREATE TABLE `forum_moderators` (
	`id` int AUTO_INCREMENT NOT NULL,
	`forumId` int NOT NULL,
	`userId` int NOT NULL,
	`assignedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `forum_moderators_id` PRIMARY KEY(`id`),
	CONSTRAINT `forum_moderator_unique` UNIQUE(`forumId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `forum_permissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`forumId` int NOT NULL,
	`permissionId` int NOT NULL,
	`enabled` boolean NOT NULL DEFAULT true,
	CONSTRAINT `forum_permissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `forum_permission_unique` UNIQUE(`forumId`,`permissionId`)
);
--> statement-breakpoint
ALTER TABLE `forum_moderators` ADD CONSTRAINT `forum_moderators_forumId_forums_id_fk` FOREIGN KEY (`forumId`) REFERENCES `forums`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `forum_moderators` ADD CONSTRAINT `forum_moderators_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `forum_moderators` ADD CONSTRAINT `forum_moderators_assignedBy_users_id_fk` FOREIGN KEY (`assignedBy`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `forum_permissions` ADD CONSTRAINT `forum_permissions_forumId_forums_id_fk` FOREIGN KEY (`forumId`) REFERENCES `forums`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `forum_permissions` ADD CONSTRAINT `forum_permissions_permissionId_permissions_id_fk` FOREIGN KEY (`permissionId`) REFERENCES `permissions`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `forum_moderator_user_idx` ON `forum_moderators` (`userId`);