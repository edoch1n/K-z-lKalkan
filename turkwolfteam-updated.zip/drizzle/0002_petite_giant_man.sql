CREATE TABLE `storage_objects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`objectKey` varchar(360) NOT NULL,
	`url` text NOT NULL,
	`filename` varchar(180) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`sizeBytes` int NOT NULL,
	`purpose` enum('avatar','wiki_attachment','ctf_attachment') NOT NULL,
	`visibility` enum('private','members','public') NOT NULL DEFAULT 'private',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `storage_objects_id` PRIMARY KEY(`id`),
	CONSTRAINT `storage_objects_objectKey_unique` UNIQUE(`objectKey`)
);
--> statement-breakpoint
ALTER TABLE `storage_objects` ADD CONSTRAINT `storage_objects_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `storage_owner_idx` ON `storage_objects` (`ownerId`,`purpose`);--> statement-breakpoint
CREATE INDEX `storage_purpose_idx` ON `storage_objects` (`purpose`,`createdAt`);