import crypto from "node:crypto";

export function hashCtfFlag(flag: string) {
  return crypto.createHash("sha256").update(flag, "utf8").digest("hex");
}

export function safeHashEquals(left: string, right: string) {
  const leftBuffer = Buffer.from(left, "utf8");
  const rightBuffer = Buffer.from(right, "utf8");
  return leftBuffer.length === rightBuffer.length && crypto.timingSafeEqual(leftBuffer, rightBuffer);
}

/** Keeps the forum format text-first and prevents HTML/script payloads from entering storage. */
export function sanitizeForumBody(input: string, maxLength = 30_000) {
  return input
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]*>/g, "")
    .replace(/javascript\s*:/gi, "")
    .replace(/vbscript\s*:/gi, "")
    .replace(/on[a-z]+\s*=/gi, "")
    .trim()
    .slice(0, maxLength);
}

/** Rejects cross-site browser mutations while allowing CLI/tests without Origin metadata. */
export function assertSameOrigin(req: { method?: string; headers?: Record<string, string | string[] | undefined> }) {
  if (req.method && req.method.toUpperCase() !== "POST") return;
  const origin = req.headers?.origin;
  const referer = req.headers?.referer;
  const host = req.headers?.host;
  const candidate = Array.isArray(origin) ? origin[0] : origin || (Array.isArray(referer) ? referer[0] : referer);
  if (!candidate || !host) return;
  const forwardedProto = req.headers?.["x-forwarded-proto"];
  const protocol = (Array.isArray(forwardedProto) ? forwardedProto[0] : forwardedProto) || "https";
  try {
    const candidateUrl = new URL(candidate);
    const expectedOrigin = `${protocol}://${host}`;
    if (candidateUrl.origin !== expectedOrigin) throw new Error("Cross-site mutation rejected.");
  } catch {
    throw new Error("Geçersiz istek kaynağı.");
  }
}
