import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function contextFor(role: "user" | "admin"): TrpcContext {
  const now = new Date();
  return {
    user: { id: 42, openId: "test-user", name: "Test Operatör", email: "test@example.com", loginMethod: "test", role, status: "active", username: "test_operator", displayName: "Test Operatör", bio: null, avatarUrl: null, coverUrl: null, customTitle: null, language: "tr", lastActiveAt: now, createdAt: now, updatedAt: now, lastSignedIn: now },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("server-side RBAC", () => {
  it("rejects non-admin access to the admin snapshot", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.admin.snapshot()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects non-admin role assignment before database access", async () => {
    const caller = appRouter.createCaller(contextFor("user"));
    await expect(caller.admin.assignRole({ userId: 1, roleId: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
