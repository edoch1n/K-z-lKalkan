import { afterEach, describe, expect, it } from "vitest";
import { assertRateLimit, clearRateLimitsForTests } from "./rateLimit";

afterEach(() => clearRateLimitsForTests());

describe("mutation rate limits", () => {
  it("blocks the request after the configured budget", () => {
    assertRateLimit("unit", 2, 60_000);
    assertRateLimit("unit", 2, 60_000);
    expect(() => assertRateLimit("unit", 2, 60_000)).toThrow("Çok sık işlem");
  });
});
