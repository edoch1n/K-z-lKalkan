import { describe, expect, it } from "vitest";
import { assertSameOrigin, hashCtfFlag, safeHashEquals, sanitizeForumBody } from "./security";

describe("server-only CTF verification", () => {
  it("accepts the exact flag hash", () => {
    const hashed = hashCtfFlag("twf{unit_test}");
    expect(safeHashEquals(hashed, hashCtfFlag("twf{unit_test}"))).toBe(true);
  });

  it("rejects wrong and differently sized hashes without throwing", () => {
    const hashed = hashCtfFlag("twf{unit_test}");
    expect(safeHashEquals(hashed, hashCtfFlag("twf{wrong}"))).toBe(false);
    expect(safeHashEquals(hashed, "short")).toBe(false);
  });
});


describe("forum input and CSRF guards", () => {
  it("strips active HTML and javascript URLs from forum bodies", () => {
    expect(sanitizeForumBody("Merhaba <script>alert(1)</script><a href=\"javascript:alert(2)\">link</a>")).toBe("Merhaba link");
  });

  it("rejects cross-site browser mutations but allows same-origin requests", () => {
    expect(() => assertSameOrigin({ method: "POST", headers: { origin: "https://evil.example", host: "app.example" } })).toThrow();
    expect(() => assertSameOrigin({ method: "POST", headers: { origin: "https://app.example", host: "app.example" } })).not.toThrow();
  });
});
