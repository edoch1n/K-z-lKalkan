import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { notifyOwner } from "./_core/notification";
import {
  createAuditLog,
  createPost,
  updateOwnPost,
  deleteOwnPost,
  createReport,
  createThread,
  getAdminSnapshot,
  getCtfChallenge,
  listCtfWriteups,
  createCtfWriteup,
  getCtfLeaderboard,
  getHomeData,
  getLeaderboard,
  getProfile,
  assignUserRole,
  setRolePermission,
  assignUserRank,
  grantAchievement,
  createAnnouncement,
  getAnnouncement,
  updateProfile,
  getThreadById,
  hasPermission,
  listCtf,
  listEvents,
  listForums,
  listInbox,
  markMessagesRead,
  deleteOwnMessage,
  listMembers,
  listNotifications,
  listReports,
  listRolesAndPermissions,
  listThreads,
  listWiki,
  getWikiArticle,
  createWikiArticle,
  joinEvent,
  markNotificationsRead,
  moderateUser,
  moderateThread,
  moderatePost,
  reviewReport,
  searchAll,
  sendDirectMessage,
  submitCtf,
  toggleReaction,
  touchUser,
  uploadUserObject,
  resolveStorageObject,
  resolveCtfAttachment,
  assignForumModerator,
  setForumPermission,
  listForumAccess,
  upsertBlock,
} from "./db";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { assertSameOrigin, hashCtfFlag, safeHashEquals } from "./security";
import { assertRateLimit } from "./rateLimit";

const pageInput = z.object({ page: z.number().int().min(1).default(1), pageSize: z.number().int().min(1).max(50).default(20) });
const targetInput = z.object({ targetType: z.enum(["post", "thread", "wiki"]), targetId: z.number().int().positive() });

const permissionProcedure = (permission: string) => protectedProcedure.use(async ({ ctx, next }) => {
  if (!(await hasPermission(ctx.user.id, permission))) throw new TRPCError({ code: "FORBIDDEN", message: "Bu işlem için yetkiniz bulunmuyor." });
  return next();
});

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Yönetim alanına erişim yetkiniz bulunmuyor." });
  return next();
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async ({ ctx }) => {
      if (ctx.user) await touchUser(ctx.user.id);
      return ctx.user;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      try { assertSameOrigin(ctx.req); } catch { throw new TRPCError({ code: "FORBIDDEN", message: "Geçersiz istek kaynağı." }); }
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  home: router({
    overview: publicProcedure.query(() => getHomeData()),
  }),
  forums: router({
    list: publicProcedure.query(() => listForums()),
  }),
  threads: router({
    list: publicProcedure.input(pageInput.extend({ forumId: z.number().int().positive().optional(), query: z.string().max(120).optional() })).query(({ input }) => listThreads(input)),
    get: publicProcedure.input(z.object({ id: z.number().int().positive(), page: z.number().int().min(1).default(1), pageSize: z.number().int().min(1).max(50).default(20) })).query(({ ctx, input }) => getThreadById(input.id, ctx.user?.id, input.page, input.pageSize)),
    create: permissionProcedure("create_thread").input(z.object({ forumId: z.number().int().positive(), title: z.string().trim().min(6).max(180), body: z.string().trim().min(10).max(30000), tags: z.array(z.string().trim().min(1).max(40)).max(5).optional() })).mutation(async ({ ctx, input }) => {
      if (["muted", "suspended", "banned"].includes(ctx.user.status)) throw new TRPCError({ code: "FORBIDDEN", message: "Hesap durumunuz yeni konu açmaya izin vermiyor." });
      try { assertRateLimit(`thread:${ctx.user.id}`, 5, 60_000); } catch (error) { throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: error instanceof Error ? error.message : "Çok sık işlem." }); }
      return createThread({ ...input, authorId: ctx.user.id });
    }),
  }),
  posts: router({
    updateOwn: protectedProcedure.input(z.object({ postId: z.number().int().positive(), body: z.string().trim().min(2).max(30000) })).mutation(({ ctx, input }) => updateOwnPost({ ...input, userId: ctx.user.id })),
    deleteOwn: protectedProcedure.input(z.object({ postId: z.number().int().positive() })).mutation(({ ctx, input }) => deleteOwnPost({ ...input, userId: ctx.user.id })),
    create: permissionProcedure("reply_thread").input(z.object({ threadId: z.number().int().positive(), body: z.string().trim().min(2).max(30000), parentPostId: z.number().int().positive().optional() })).mutation(async ({ ctx, input }) => {
      if (["muted", "suspended", "banned"].includes(ctx.user.status)) throw new TRPCError({ code: "FORBIDDEN", message: "Hesap durumunuz yanıt göndermeye izin vermiyor." });
      try { assertRateLimit(`post:${ctx.user.id}`, 12, 60_000); } catch (error) { throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: error instanceof Error ? error.message : "Çok sık işlem." }); }
      return createPost({ ...input, authorId: ctx.user.id });
    }),
  }),
  reactions: router({
    toggle: protectedProcedure.input(targetInput).mutation(({ ctx, input }) => { assertRateLimit(`reaction:${ctx.user.id}`, 30, 60_000); return toggleReaction({ ...input, userId: ctx.user.id }); }),
  }),
  notifications: router({
    list: protectedProcedure.query(({ ctx }) => listNotifications(ctx.user.id)),
    markRead: protectedProcedure.input(z.object({ id: z.number().int().positive().optional() })).mutation(({ ctx, input }) => markNotificationsRead(ctx.user.id, input.id)),
  }),
  messages: router({
    inbox: protectedProcedure.input(z.object({ query: z.string().max(120).optional() }).optional()).query(({ ctx, input }) => listInbox(ctx.user.id, input?.query)),
    markRead: protectedProcedure.input(z.object({ conversationId: z.number().int().positive() })).mutation(({ ctx, input }) => markMessagesRead(ctx.user.id, input.conversationId)),
    delete: protectedProcedure.input(z.object({ messageId: z.number().int().positive() })).mutation(({ ctx, input }) => deleteOwnMessage(ctx.user.id, input.messageId)),
    send: protectedProcedure.input(z.object({ recipientId: z.number().int().positive(), body: z.string().trim().min(2).max(5000) })).mutation(({ ctx, input }) => { assertRateLimit(`message:${ctx.user.id}`, 10, 60_000); return sendDirectMessage({ ...input, senderId: ctx.user.id }); }),
  }),
  members: router({
    list: publicProcedure.input(z.object({ page: z.number().int().min(1).default(1), query: z.string().max(100).optional() })).query(({ input }) => listMembers(input)),
  }),
  profiles: router({
    me: protectedProcedure.query(({ ctx }) => getProfile(ctx.user.id)),
    byId: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getProfile(input.id)),
    update: protectedProcedure.input(z.object({ username: z.string().trim().min(3).max(32).regex(/^[a-zA-Z0-9_ğüşöçıİĞÜŞÖÇ-]+$/).optional(), displayName: z.string().trim().min(2).max(80).optional(), bio: z.string().max(1000).optional(), socialLinks: z.string().max(2000).optional(), privacy: z.enum(["public", "members", "private"]).optional(), showOnline: z.boolean().optional() })).mutation(({ ctx, input }) => updateProfile({ ...input, userId: ctx.user.id })),
  }),
  search: router({
    all: publicProcedure.input(z.object({ query: z.string().max(120), page: z.number().int().min(1).default(1), pageSize: z.number().int().min(1).max(20).default(8) })).query(({ input }) => searchAll(input)),
  }),
  leaderboard: router({
    list: publicProcedure.input(z.object({ kind: z.enum(["posts", "threads", "reactions", "active"]).default("posts"), period: z.enum(["all", "week", "month"]).default("all") })).query(({ input }) => getLeaderboard(input.kind, input.period)),
  }),
  reports: router({
    create: protectedProcedure.input(z.object({ targetType: z.enum(["post", "thread", "profile", "message"]), targetId: z.number().int().positive(), category: z.enum(["spam", "harassment", "inappropriate", "rules", "other"]), description: z.string().trim().max(2000).optional() })).mutation(async ({ ctx, input }) => {
      try { assertRateLimit(`report:${ctx.user.id}`, 5, 60_000); } catch (error) { throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: error instanceof Error ? error.message : "Çok sık rapor gönderildi." }); }
      const result = await createReport({ ...input, reporterId: ctx.user.id });
      if (input.category === "harassment" || input.targetType === "message") {
        try { await notifyOwner({ title: "TURKWOLFTEAM kritik rapor", content: `${input.targetType} #${input.targetId} için ${input.category} kategorisinde yeni rapor açıldı.` }); } catch (error) { console.warn("[Owner notification] unavailable", error); }
      }
      return result;
    }),
    list: permissionProcedure("manage_reports").query(() => listReports()),
    review: permissionProcedure("manage_reports").input(z.object({ id: z.number().int().positive(), state: z.enum(["in_review", "resolved", "rejected"]), notes: z.string().trim().max(2000).optional() })).mutation(({ ctx, input }) => reviewReport({ ...input, reviewerId: ctx.user.id })),
  }),
  moderation: router({
    thread: permissionProcedure("manage_content").input(z.object({ threadId: z.number().int().positive(), action: z.enum(["lock", "unlock", "pin", "unpin", "move", "edit"]), forumId: z.number().int().positive().optional(), title: z.string().trim().min(6).max(180).optional() })).mutation(({ ctx, input }) => moderateThread({ ...input, moderatorId: ctx.user.id })),
    post: permissionProcedure("manage_content").input(z.object({ postId: z.number().int().positive(), action: z.enum(["delete", "restore", "edit"]), body: z.string().trim().min(2).max(30000).optional() })).mutation(({ ctx, input }) => moderatePost({ ...input, moderatorId: ctx.user.id })),
    userStatus: permissionProcedure("manage_users").input(z.object({ targetId: z.number().int().positive(), status: z.enum(["active", "warned", "muted", "suspended", "banned"]), reason: z.string().trim().min(3).max(1000) })).mutation(async ({ ctx, input }) => {
      const result = await moderateUser({ ...input, moderatorId: ctx.user.id });
      try { await notifyOwner({ title: "TURKWOLFTEAM moderasyon olayı", content: `Kullanıcı #${input.targetId} durumu ${input.status} olarak güncellendi.` }); } catch (error) { console.warn("[Owner notification] unavailable", error); }
      await createAuditLog({ actorId: ctx.user.id, action: `user_${input.status}`, targetType: "user", targetId: input.targetId, metadata: JSON.stringify({ reason: input.reason }) });
      return result;
    }),
  }),
  admin: router({
    snapshot: adminProcedure.query(() => getAdminSnapshot()),
    roles: adminProcedure.query(() => listRolesAndPermissions()),
    reports: adminProcedure.query(() => listReports()),
    assignRole: adminProcedure.input(z.object({ userId: z.number().int().positive(), roleId: z.number().int().positive() })).mutation(({ ctx, input }) => assignUserRole({ ...input, assignedBy: ctx.user.id })),
    setPermission: adminProcedure.input(z.object({ roleId: z.number().int().positive(), permissionId: z.number().int().positive(), enabled: z.boolean() })).mutation(({ ctx, input }) => setRolePermission({ ...input, actorId: ctx.user.id })),
    assignRank: adminProcedure.input(z.object({ userId: z.number().int().positive(), rankId: z.number().int().positive() })).mutation(({ ctx, input }) => assignUserRank({ ...input, assignedBy: ctx.user.id })),
    grantAchievement: adminProcedure.input(z.object({ userId: z.number().int().positive(), achievementId: z.number().int().positive(), progress: z.number().int().min(0).max(100).default(100) })).mutation(({ ctx, input }) => grantAchievement({ ...input, actorId: ctx.user.id })),
    announce: adminProcedure.input(z.object({ title: z.string().trim().min(3).max(180), content: z.string().trim().min(3).max(10000), priority: z.enum(["normal", "high", "critical"]), visibility: z.enum(["public", "members", "staff"]) })).mutation(async ({ ctx, input }) => { const result = await createAnnouncement({ ...input, authorId: ctx.user.id }); if (input.priority === "critical") { try { await notifyOwner({ title: "TURKWOLFTEAM kritik duyuru", content: input.title }); } catch (error) { console.warn("[Owner notification] unavailable", error); } } return result; }),
    forumAccess: adminProcedure.input(z.object({ forumId: z.number().int().positive() })).query(({ input }) => listForumAccess(input.forumId)),
    assignForumModerator: adminProcedure.input(z.object({ forumId: z.number().int().positive(), userId: z.number().int().positive() })).mutation(({ ctx, input }) => assignForumModerator({ ...input, assignedBy: ctx.user.id })),
    setForumPermission: adminProcedure.input(z.object({ forumId: z.number().int().positive(), permissionId: z.number().int().positive(), enabled: z.boolean() })).mutation(({ ctx, input }) => setForumPermission({ ...input, actorId: ctx.user.id })),
  }),
  announcements: router({
    get: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getAnnouncement(input.id)),
  }),
  wiki: router({
    list: publicProcedure.query(() => listWiki()),
    get: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getWikiArticle(input.id)),
    adminCreate: adminProcedure.input(z.object({ categoryId: z.number().int().positive(), title: z.string().trim().min(3).max(180), summary: z.string().trim().min(3).max(500), content: z.string().trim().min(20).max(50_000), status: z.enum(["draft", "published"]) })).mutation(({ ctx, input }) => createWikiArticle({ ...input, authorId: ctx.user.id })),
  }),
  events: router({
    list: publicProcedure.query(() => listEvents()),
    join: protectedProcedure.input(z.object({ eventId: z.number().int().positive() })).mutation(({ ctx, input }) => joinEvent(input.eventId, ctx.user.id)),
  }),
  ctf: router({
    list: publicProcedure.query(() => listCtf()),
    get: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getCtfChallenge(input.id)),
    writeups: publicProcedure.input(z.object({ challengeId: z.number().int().positive() })).query(({ input }) => listCtfWriteups(input.challengeId)),
    attachment: protectedProcedure.input(z.object({ challengeId: z.number().int().positive() })).query(async ({ ctx, input }) => { try { return await resolveCtfAttachment({ challengeId: input.challengeId, viewerId: ctx.user.id, viewerRole: ctx.user.role }); } catch (error) { throw new TRPCError({ code: "FORBIDDEN", message: error instanceof Error ? error.message : "Dosya erişimi reddedildi." }); } }),
    createWriteup: protectedProcedure.input(z.object({ challengeId: z.number().int().positive(), title: z.string().trim().min(3).max(180), content: z.string().trim().min(20).max(20_000) })).mutation(({ ctx, input }) => createCtfWriteup({ ...input, authorId: ctx.user.id })),
    leaderboard: publicProcedure.query(() => getCtfLeaderboard()),
    submit: protectedProcedure.input(z.object({ challengeId: z.number().int().positive(), flag: z.string().trim().min(1).max(500) })).mutation(async ({ ctx, input }) => {
      try { assertRateLimit(`ctf:${ctx.user.id}:${input.challengeId}`, 10, 60_000); } catch (error) { throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: error instanceof Error ? error.message : "Çok sık deneme." }); }
      const answerHash = hashCtfFlag(input.flag);
      const { getDb } = await import("./db");
      const { ctfChallenges } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "CTF servisi kullanılamıyor." });
      const challenge = await db.select({ flagHash: ctfChallenges.flagHash, status: ctfChallenges.status }).from(ctfChallenges).where(eq(ctfChallenges.id, input.challengeId)).limit(1);
      if (!challenge[0] || challenge[0].status !== "published") throw new TRPCError({ code: "NOT_FOUND", message: "Challenge bulunamadı." });
      const isCorrect = safeHashEquals(answerHash, challenge[0].flagHash);
      const result = await submitCtf({ challengeId: input.challengeId, userId: ctx.user.id, answerHash, isCorrect });
      return { correct: result.correct, alreadySolved: result.alreadySolved, duplicate: result.duplicate };
    }),
  }),
  media: router({
    upload: protectedProcedure.input(z.object({ filename: z.string().trim().min(1).max(180), mimeType: z.string().trim().max(120), base64: z.string().regex(/^[A-Za-z0-9+/=]+$/).max(14_000_000), purpose: z.enum(["avatar", "cover", "wiki_attachment", "ctf_attachment"]) })).mutation(async ({ ctx, input }) => {
      if (!["avatar", "cover"].includes(input.purpose) && ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Bu ek türü yalnızca yöneticiler yükleyebilir." });
      try { return await uploadUserObject({ ...input, userId: ctx.user.id }); } catch (error) { throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Dosya yüklenemedi." }); }
    }),
    resolve: protectedProcedure.input(z.object({ objectId: z.number().int().positive() })).query(({ ctx, input }) => resolveStorageObject({ objectId: input.objectId, viewerId: ctx.user.id, viewerRole: ctx.user.role })),
  }),
  social: router({
    block: protectedProcedure.input(z.object({ userId: z.number().int().positive() })).mutation(({ ctx, input }) => {
      if (ctx.user.id === input.userId) throw new TRPCError({ code: "BAD_REQUEST", message: "Kendinizi engelleyemezsiniz." });
      return upsertBlock(ctx.user.id, input.userId);
    }),
  }),
});

export type AppRouter = typeof appRouter;
