import { describe, expect, it } from "vitest";
import { validateUploadBytes } from "./db";

describe("object storage upload policy", () => {
  it("accepts a GIF signature for avatar uploads", () => {
    expect(validateUploadBytes("image/gif", Buffer.from("GIF89a"))).toBe(true);
  });

  it("rejects a spoofed GIF payload", () => {
    expect(validateUploadBytes("image/gif", Buffer.from("not-a-gif"))).toBe(false);
  });
});
