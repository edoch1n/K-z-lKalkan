import { and, asc, count, desc, eq, gte, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  achievements,
  announcements,
  auditLogs,
  blocks,
  categories,
  conversationMembers,
  conversations,
  ctfChallenges,
  ctfSubmissions,
  ctfWriteups,
  eventParticipants,
  events,
  forums,
  forumModerators,
  forumPermissions,
  mentions,
  messages,
  moderationLogs,
  notifications,
  permissions,
  posts,
  profiles,
  ranks,
  reactions,
  reports,
  rolePermissions,
  roles,
  settings,
  storageObjects,
  tags,
  threadReads,
  threadTags,
  threads,
  userAchievements,
  userRanks,
  userRoles,
  users,
  wikiArticles,
  wikiCategories,
  wikiRevisions,
  type InsertUser,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { storageGetSignedUrl, storagePut } from "./storage";
import { sanitizeForumBody } from "./security";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await requireDb();
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod", "username", "displayName", "bio", "avatarUrl", "coverUrl", "customTitle", "language"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] as any;
      updateSet[field] = user[field];
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  } else {
    values.lastSignedIn = new Date();
    updateSet.lastSignedIn = new Date();
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  const createdUser = await db.select({ id: users.id }).from(users).where(eq(users.openId, user.openId)).limit(1);
  if (createdUser[0]) await db.insert(profiles).values({ userId: createdUser[0].id }).onDuplicateKeyUpdate({ set: { userId: createdUser[0].id } });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return rows[0];
}

export async function ensureProfile(userId: number) {
  const db = await requireDb();
  await db.insert(profiles).values({ userId }).onDuplicateKeyUpdate({ set: { userId } });
}

export async function touchUser(userId: number) {
  const db = await getDb();
  if (db) await db.update(users).set({ lastActiveAt: new Date() }).where(eq(users.id, userId));
}

export async function getHomeData() {
  const db = await requireDb();
  const [categoryRows, latestThreads, latestAnnouncements, stats, activeMembers] = await Promise.all([
    db.select().from(categories).where(eq(categories.isVisible, true)).orderBy(asc(categories.sortOrder)),
    db
      .select({ id: threads.id, title: threads.title, slug: threads.slug, excerpt: threads.excerpt, replyCount: threads.replyCount, isPinned: threads.isPinned, lastPostAt: threads.lastPostAt, authorName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, forumName: forums.name, forumSlug: forums.slug })
      .from(threads)
      .leftJoin(users, eq(users.id, threads.authorId))
      .leftJoin(forums, eq(forums.id, threads.forumId))
      .where(eq(threads.status, "open"))
      .orderBy(desc(threads.isPinned), desc(threads.lastPostAt))
      .limit(6),
    db.select().from(announcements).where(or(eq(announcements.visibility, "public"), eq(announcements.visibility, "members"))).orderBy(desc(announcements.createdAt)).limit(3),
    Promise.all([
      db.select({ value: count() }).from(users).where(eq(users.status, "active")),
      db.select({ value: count() }).from(threads),
      db.select({ value: count() }).from(posts),
      db.select({ value: count() }).from(users).where(sql`${users.lastActiveAt} >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)`),
    ]),
    db.select({ id: users.id, name: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, username: users.username, avatarUrl: users.avatarUrl, lastActiveAt: users.lastActiveAt }).from(users).where(eq(users.status, "active")).orderBy(desc(users.lastActiveAt)).limit(5),
  ]);
  const categoryIds = categoryRows.map((row) => row.id);
  const forumRows = categoryIds.length ? await db.select().from(forums).where(eq(forums.isVisible, true)).orderBy(asc(forums.sortOrder)) : [];
  return {
    categories: categoryRows.map((category) => ({ ...category, forums: forumRows.filter((forum) => forum.categoryId === category.id) })),
    latestThreads,
    announcements: latestAnnouncements,
    activeMembers,
    stats: { members: Number(stats[0][0]?.value ?? 0), threads: Number(stats[1][0]?.value ?? 0), posts: Number(stats[2][0]?.value ?? 0), online: Number(stats[3][0]?.value ?? 0) },
  };
}

export async function listForums() {
  const db = await requireDb();
  const rows = await db.select({ forum: forums, category: categories }).from(forums).innerJoin(categories, eq(categories.id, forums.categoryId)).where(eq(forums.isVisible, true)).orderBy(asc(categories.sortOrder), asc(forums.sortOrder));
  return rows;
}

export async function listThreads(input: { forumId?: number; page: number; pageSize: number; query?: string }) {
  const db = await requireDb();
  const conditions = [eq(threads.status, "open")];
  if (input.forumId) conditions.push(eq(threads.forumId, input.forumId));
  if (input.query) conditions.push(or(like(threads.title, `%${input.query}%`), like(threads.excerpt, `%${input.query}%`))!);
  const [rows, totalRows] = await Promise.all([
    db.select({ id: threads.id, title: threads.title, slug: threads.slug, excerpt: threads.excerpt, replyCount: threads.replyCount, viewCount: threads.viewCount, status: threads.status, isPinned: threads.isPinned, isAnnouncement: threads.isAnnouncement, lastPostAt: threads.lastPostAt, authorName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, forumName: forums.name, forumSlug: forums.slug }).from(threads).leftJoin(users, eq(users.id, threads.authorId)).leftJoin(forums, eq(forums.id, threads.forumId)).where(and(...conditions)).orderBy(desc(threads.isPinned), desc(threads.lastPostAt)).limit(input.pageSize).offset((input.page - 1) * input.pageSize),
    db.select({ value: count() }).from(threads).where(and(...conditions)),
  ]);
  return { rows, total: Number(totalRows[0]?.value ?? 0), page: input.page, pageSize: input.pageSize };
}

export async function getThreadById(id: number, viewerId?: number, page = 1, pageSize = 20) {
  const db = await requireDb();
  const threadRows = await db.select({ thread: threads, forum: forums, authorName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, authorUsername: users.username }).from(threads).leftJoin(forums, eq(forums.id, threads.forumId)).leftJoin(users, eq(users.id, threads.authorId)).where(eq(threads.id, id)).limit(1);
  if (!threadRows[0]) return null;
  const postCondition = and(eq(posts.threadId, id), eq(posts.isDeleted, false));
  const [threadPosts, postTotal] = await Promise.all([
    db.select({ post: posts, authorName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, authorUsername: users.username, avatarUrl: users.avatarUrl, rankName: ranks.name, rankColor: ranks.color }).from(posts).leftJoin(users, eq(users.id, posts.authorId)).leftJoin(userRanks, eq(userRanks.userId, posts.authorId)).leftJoin(ranks, eq(ranks.id, userRanks.rankId)).where(postCondition).orderBy(asc(posts.createdAt)).limit(pageSize).offset((page - 1) * pageSize),
    db.select({ value: count() }).from(posts).where(postCondition),
  ]);
  await db.update(threads).set({ viewCount: sql`${threads.viewCount} + 1` }).where(eq(threads.id, id));
  if (viewerId) await db.insert(threadReads).values({ userId: viewerId, threadId: id, lastReadAt: new Date() }).onDuplicateKeyUpdate({ set: { lastReadAt: new Date() } });
  return { ...threadRows[0], posts: threadPosts, pagination: { page, pageSize, total: Number(postTotal[0]?.value ?? 0), hasMore: page * pageSize < Number(postTotal[0]?.value ?? 0) } };
}

export async function createThread(input: { forumId: number; authorId: number; title: string; body: string; tags?: string[] }) {
  const db = await requireDb();
  const safeBody = sanitizeForumBody(input.body);
  const slugBase = input.title.toLowerCase().replace(/[^a-z0-9ğüşöçıİĞÜŞÖÇ]+/gi, "-").replace(/^-|-$/g, "").slice(0, 180) || "konu";
  const slug = `${slugBase}-${Date.now().toString(36)}`;
  const result = await db.transaction(async (tx) => {
    const insertThread = await tx.insert(threads).values({ forumId: input.forumId, authorId: input.authorId, title: input.title, slug, excerpt: safeBody.slice(0, 240) });
    const threadId = Number(insertThread[0].insertId);
    await tx.insert(posts).values({ threadId, authorId: input.authorId, body: safeBody });
    await tx.update(forums).set({ threadCount: sql`${forums.threadCount} + 1`, postCount: sql`${forums.postCount} + 1`, lastPostAt: new Date() }).where(eq(forums.id, input.forumId));
    await tx.update(profiles).set({ threadCount: sql`${profiles.threadCount} + 1`, postCount: sql`${profiles.postCount} + 1` }).where(eq(profiles.userId, input.authorId));
    if (input.tags?.length) {
      for (const tagName of input.tags.slice(0, 5)) {
        const normalized = tagName.trim().toLowerCase().replace(/\s+/g, "-");
        if (!normalized) continue;
        await tx.insert(tags).values({ name: tagName.trim().slice(0, 40), slug: normalized.slice(0, 60) }).onDuplicateKeyUpdate({ set: { name: tagName.trim().slice(0, 40) } });
        const tag = await tx.select().from(tags).where(eq(tags.slug, normalized.slice(0, 60))).limit(1);
        if (tag[0]) await tx.insert(threadTags).values({ threadId, tagId: tag[0].id }).onDuplicateKeyUpdate({ set: { threadId } });
      }
    }
    return { id: threadId, slug };
  });
  await refreshUserProgress(input.authorId);
  return result;
}

export async function createPost(input: { threadId: number; authorId: number; body: string; parentPostId?: number }) {
  const db = await requireDb();
  const safeBody = sanitizeForumBody(input.body);
  const result = await db.transaction(async (tx) => {
    const thread = await tx.select().from(threads).where(eq(threads.id, input.threadId)).limit(1);
    if (!thread[0] || thread[0].status !== "open") throw new Error("Bu konu yeni yanıtlara kapalı.");
    const parent = input.parentPostId ? (await tx.select({ id: posts.id, threadId: posts.threadId, authorId: posts.authorId }).from(posts).where(eq(posts.id, input.parentPostId)).limit(1))[0] : undefined;
    if (input.parentPostId && (!parent || parent.threadId !== input.threadId)) throw new Error("Alıntılanan gönderi bu konuya ait değil.");
    const inserted = await tx.insert(posts).values({ threadId: input.threadId, authorId: input.authorId, body: safeBody, parentPostId: input.parentPostId });
    const postId = Number(inserted[0].insertId);
    await tx.update(threads).set({ replyCount: sql`${threads.replyCount} + 1`, lastPostAt: new Date() }).where(eq(threads.id, input.threadId));
    await tx.update(forums).set({ postCount: sql`${forums.postCount} + 1`, lastPostAt: new Date() }).where(eq(forums.id, thread[0].forumId));
    await tx.update(profiles).set({ postCount: sql`${profiles.postCount} + 1` }).where(eq(profiles.userId, input.authorId));
    const mentionedNames = Array.from(safeBody.matchAll(/@([a-zA-Z0-9_ğüşöçıİĞÜŞÖÇ-]{2,32})/g)).map((match) => match[1]);
    for (const username of mentionedNames.slice(0, 10)) {
      const mentioned = await tx.select().from(users).where(eq(users.username, username)).limit(1);
      if (mentioned[0] && mentioned[0].id !== input.authorId) {
        await tx.insert(mentions).values({ userId: mentioned[0].id, postId });
        await tx.insert(notifications).values({ userId: mentioned[0].id, actorId: input.authorId, type: "mention", title: "Bir mention aldınız", body: "Bir topluluk üyesi sizi bir gönderide andı.", href: `/threads/${input.threadId}` });
      }
    }
    if (thread[0].authorId !== input.authorId) await tx.insert(notifications).values({ userId: thread[0].authorId, actorId: input.authorId, type: "reply", title: "Konunuza yeni yanıt", body: "Açtığınız konuya yeni bir yanıt geldi.", href: `/threads/${input.threadId}` });
    if (parent && parent.authorId !== input.authorId) await tx.insert(notifications).values({ userId: parent.authorId, actorId: input.authorId, type: "quote", title: "Gönderiniz alıntılandı", body: "Bir topluluk üyesi gönderinizi alıntıladı.", href: `/threads/${input.threadId}` });
    return { id: postId };
  });
  await refreshUserProgress(input.authorId);
  return result;
}

export async function toggleReaction(input: { userId: number; targetType: "post" | "thread" | "wiki"; targetId: number }) {
  const db = await requireDb();
  const existing = await db.select().from(reactions).where(and(eq(reactions.userId, input.userId), eq(reactions.targetType, input.targetType), eq(reactions.targetId, input.targetId))).limit(1);
  if (existing[0]) {
    await db.delete(reactions).where(eq(reactions.id, existing[0].id));
    return { active: false };
  }
  await db.insert(reactions).values(input);
  let ownerId: number | undefined;
  if (input.targetType === "post") ownerId = (await db.select({ authorId: posts.authorId }).from(posts).where(eq(posts.id, input.targetId)).limit(1))[0]?.authorId;
  if (input.targetType === "thread") ownerId = (await db.select({ authorId: threads.authorId }).from(threads).where(eq(threads.id, input.targetId)).limit(1))[0]?.authorId;
  if (input.targetType === "wiki") ownerId = (await db.select({ authorId: wikiArticles.authorId }).from(wikiArticles).where(eq(wikiArticles.id, input.targetId)).limit(1))[0]?.authorId;
  if (ownerId && ownerId !== input.userId) await db.insert(notifications).values({ userId: ownerId, actorId: input.userId, type: "reaction", title: "Yeni reaksiyon", body: "İçeriğiniz bir topluluk üyesi tarafından faydalı bulundu.", href: input.targetType === "post" || input.targetType === "thread" ? `/threads/${input.targetId}` : `/wiki/${input.targetId}` });
  return { active: true };
}

export async function listNotifications(userId: number) {
  const db = await requireDb();
  const [rows, unread] = await Promise.all([
    db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(50),
    db.select({ value: count() }).from(notifications).where(and(eq(notifications.userId, userId), eq(notifications.isRead, false))),
  ]);
  return { rows, unread: Number(unread[0]?.value ?? 0) };
}

export async function markNotificationsRead(userId: number, id?: number) {
  const db = await requireDb();
  if (id) await db.update(notifications).set({ isRead: true }).where(and(eq(notifications.userId, userId), eq(notifications.id, id)));
  else await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, userId));
}

export async function listMembers(input: { page: number; query?: string }) {
  const db = await requireDb();
  const condition = input.query ? or(like(users.username, `%${input.query}%`), like(users.displayName, `%${input.query}%`), like(users.name, `%${input.query}%`)) : undefined;
  const rows = await db.select({ id: users.id, username: users.username, name: users.name, displayName: users.displayName, avatarUrl: users.avatarUrl, lastActiveAt: users.lastActiveAt, status: users.status, profile: profiles }).from(users).leftJoin(profiles, eq(profiles.userId, users.id)).where(condition).orderBy(desc(users.lastActiveAt)).limit(24).offset((input.page - 1) * 24);
  return rows;
}

export async function searchAll(input: { query: string; page: number; pageSize: number }) {
  const db = await requireDb();
  if (!input.query.trim()) return { users: [], threads: [], posts: [], forums: [], tags: [], wiki: [], ctf: [], page: input.page, pageSize: input.pageSize, hasMore: false };
  const needle = `%${input.query.trim()}%`;
  const offset = (input.page - 1) * input.pageSize;
  const [userRows, threadRows, postRows, forumRows, tagRows, wikiRows, ctfRows] = await Promise.all([
    db.select({ id: users.id, username: users.username, displayName: users.displayName, name: users.name }).from(users).where(or(like(users.username, needle), like(users.displayName, needle), like(users.name, needle))).limit(input.pageSize).offset(offset),
    db.select({ id: threads.id, title: threads.title, slug: threads.slug, excerpt: threads.excerpt }).from(threads).where(or(like(threads.title, needle), like(threads.excerpt, needle))).limit(input.pageSize).offset(offset),
    db.select({ id: posts.id, threadId: posts.threadId, body: posts.body }).from(posts).where(and(eq(posts.isDeleted, false), like(posts.body, needle))).limit(input.pageSize).offset(offset),
    db.select({ id: forums.id, name: forums.name, slug: forums.slug, description: forums.description }).from(forums).where(or(like(forums.name, needle), like(forums.description, needle))).limit(input.pageSize).offset(offset),
    db.select({ id: tags.id, name: tags.name, slug: tags.slug }).from(tags).where(or(like(tags.name, needle), like(tags.slug, needle))).limit(input.pageSize).offset(offset),
    db.select({ id: wikiArticles.id, title: wikiArticles.title, slug: wikiArticles.slug, summary: wikiArticles.summary }).from(wikiArticles).where(and(eq(wikiArticles.status, "published"), or(like(wikiArticles.title, needle), like(wikiArticles.summary, needle)))).limit(input.pageSize).offset(offset),
    db.select({ id: ctfChallenges.id, title: ctfChallenges.title, slug: ctfChallenges.slug, category: ctfChallenges.category, difficulty: ctfChallenges.difficulty, points: ctfChallenges.points }).from(ctfChallenges).where(and(eq(ctfChallenges.status, "published"), like(ctfChallenges.title, needle))).limit(input.pageSize).offset(offset),
  ]);
  const hasMore = [userRows, threadRows, postRows, forumRows, tagRows, wikiRows, ctfRows].some((rows) => rows.length === input.pageSize);
  return { users: userRows, threads: threadRows, posts: postRows, forums: forumRows, tags: tagRows, wiki: wikiRows, ctf: ctfRows, page: input.page, pageSize: input.pageSize, hasMore };
}

export async function getLeaderboard(kind: "posts" | "threads" | "reactions" | "active", period: "all" | "week" | "month" = "all") {
  const db = await requireDb();
  if (period === "all") {
    if (kind === "threads") return db.select({ userId: users.id, name: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, value: profiles.threadCount }).from(profiles).innerJoin(users, eq(users.id, profiles.userId)).orderBy(desc(profiles.threadCount)).limit(20);
    if (kind === "reactions") return db.select({ userId: users.id, name: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, value: profiles.reactionCount }).from(profiles).innerJoin(users, eq(users.id, profiles.userId)).orderBy(desc(profiles.reactionCount)).limit(20);
    return db.select({ userId: users.id, name: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, value: profiles.postCount }).from(profiles).innerJoin(users, eq(users.id, profiles.userId)).orderBy(desc(profiles.postCount)).limit(20);
  }
  const cutoff = new Date(Date.now() - (period === "week" ? 7 : 30) * 24 * 60 * 60 * 1000);
  if (kind === "threads") return db.select({ userId: users.id, name: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, value: count(threads.id) }).from(threads).innerJoin(users, eq(users.id, threads.authorId)).where(gte(threads.createdAt, cutoff)).groupBy(users.id, users.displayName, users.name).orderBy(desc(count(threads.id))).limit(20);
  if (kind === "reactions") return db.select({ userId: users.id, name: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, value: count(reactions.id) }).from(reactions).innerJoin(users, eq(users.id, reactions.userId)).where(gte(reactions.createdAt, cutoff)).groupBy(users.id, users.displayName, users.name).orderBy(desc(count(reactions.id))).limit(20);
  return db.select({ userId: users.id, name: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, value: count(posts.id) }).from(posts).innerJoin(users, eq(users.id, posts.authorId)).where(and(eq(posts.isDeleted, false), gte(posts.createdAt, cutoff))).groupBy(users.id, users.displayName, users.name).orderBy(desc(count(posts.id))).limit(20);
}

export async function createReport(input: { reporterId: number; targetType: "post" | "thread" | "profile" | "message"; targetId: number; category: "spam" | "harassment" | "inappropriate" | "rules" | "other"; description?: string }) {
  const db = await requireDb();
  const created = await db.insert(reports).values(input);
  return { id: Number(created[0].insertId) };
}

export async function listReports() {
  const db = await requireDb();
  return db.select({ report: reports, reporterName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')` }).from(reports).leftJoin(users, eq(users.id, reports.reporterId)).orderBy(asc(reports.state), desc(reports.createdAt)).limit(100);
}

export async function reviewReport(input: { id: number; reviewerId: number; state: "in_review" | "resolved" | "rejected"; notes?: string }) {
  const db = await requireDb();
  return db.transaction(async (tx) => {
    await tx.update(reports).set({ state: input.state, moderatorNotes: input.notes, reviewedBy: input.reviewerId, reviewedAt: new Date() }).where(eq(reports.id, input.id));
    await tx.insert(moderationLogs).values({ moderatorId: input.reviewerId, action: `report_${input.state}`, targetType: "report", targetId: input.id, reason: input.notes });
    return { success: true };
  });
}

export async function moderateUser(input: { targetId: number; moderatorId: number; status: "active" | "warned" | "muted" | "suspended" | "banned"; reason: string }) {
  const db = await requireDb();
  return db.transaction(async (tx) => {
    await tx.update(users).set({ status: input.status }).where(eq(users.id, input.targetId));
    await tx.insert(moderationLogs).values({ moderatorId: input.moderatorId, action: `user_${input.status}`, targetType: "user", targetId: input.targetId, reason: input.reason });
    await tx.insert(notifications).values({ userId: input.targetId, actorId: input.moderatorId, type: "moderation", title: "Hesap durumunuz güncellendi", body: input.reason });
    return { success: true };
  });
}

export async function getAdminSnapshot() {
  const db = await requireDb();
  const [usersCount, onlineCount, threadCount, postCount, reportCount, challengeCount, eventCount, recentLogs] = await Promise.all([
    db.select({ value: count() }).from(users), db.select({ value: count() }).from(users).where(sql`${users.lastActiveAt} >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)`), db.select({ value: count() }).from(threads), db.select({ value: count() }).from(posts), db.select({ value: count() }).from(reports).where(or(eq(reports.state, "pending"), eq(reports.state, "in_review"))), db.select({ value: count() }).from(ctfChallenges), db.select({ value: count() }).from(events), db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(8),
  ]);
  return { totals: { users: Number(usersCount[0]?.value ?? 0), online: Number(onlineCount[0]?.value ?? 0), threads: Number(threadCount[0]?.value ?? 0), posts: Number(postCount[0]?.value ?? 0), reports: Number(reportCount[0]?.value ?? 0), challenges: Number(challengeCount[0]?.value ?? 0), events: Number(eventCount[0]?.value ?? 0) }, recentLogs };
}

export async function listWiki() {
  const db = await requireDb();
  return db.select({ article: wikiArticles, categoryName: wikiCategories.name, authorName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')` }).from(wikiArticles).innerJoin(wikiCategories, eq(wikiCategories.id, wikiArticles.categoryId)).leftJoin(users, eq(users.id, wikiArticles.authorId)).where(eq(wikiArticles.status, "published")).orderBy(desc(wikiArticles.updatedAt)).limit(50);
}

export async function listEvents() {
  const db = await requireDb();
  return db.select({ event: events, organizerName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')` }).from(events).leftJoin(users, eq(users.id, events.organizerId)).where(eq(events.status, "published")).orderBy(asc(events.startsAt)).limit(50);
}

export async function listCtf() {
  const db = await requireDb();
  return db.select({ id: ctfChallenges.id, title: ctfChallenges.title, slug: ctfChallenges.slug, description: ctfChallenges.description, category: ctfChallenges.category, difficulty: ctfChallenges.difficulty, points: ctfChallenges.points, hints: ctfChallenges.hints, solveCount: ctfChallenges.solveCount }).from(ctfChallenges).where(eq(ctfChallenges.status, "published")).orderBy(asc(ctfChallenges.points)).limit(50);
}

export async function submitCtf(input: { challengeId: number; userId: number; answerHash: string; isCorrect: boolean }) {
  const db = await requireDb();
  const [existing, duplicate] = await Promise.all([
    db.select().from(ctfSubmissions).where(and(eq(ctfSubmissions.challengeId, input.challengeId), eq(ctfSubmissions.userId, input.userId), eq(ctfSubmissions.isCorrect, true))).limit(1),
    db.select({ id: ctfSubmissions.id }).from(ctfSubmissions).where(and(eq(ctfSubmissions.challengeId, input.challengeId), eq(ctfSubmissions.userId, input.userId), eq(ctfSubmissions.answerHash, input.answerHash))).limit(1),
  ]);
  if (!duplicate[0]) await db.insert(ctfSubmissions).values(input);
  if (input.isCorrect && !existing[0]) await db.update(ctfChallenges).set({ solveCount: sql`${ctfChallenges.solveCount} + 1` }).where(eq(ctfChallenges.id, input.challengeId));
  return { correct: input.isCorrect, alreadySolved: Boolean(existing[0]), duplicate: Boolean(duplicate[0]) };
}

export async function getProfile(userId: number) {
  const db = await requireDb();
  const user = await db.select({ user: users, profile: profiles }).from(users).leftJoin(profiles, eq(profiles.userId, users.id)).where(eq(users.id, userId)).limit(1);
  if (!user[0]) return null;
  const [rankRows, earned] = await Promise.all([
    db.select({ rank: ranks }).from(userRanks).innerJoin(ranks, eq(ranks.id, userRanks.rankId)).where(eq(userRanks.userId, userId)).orderBy(desc(ranks.sortOrder)),
    db.select({ achievement: achievements, unlockedAt: userAchievements.unlockedAt, progress: userAchievements.progress }).from(userAchievements).innerJoin(achievements, eq(achievements.id, userAchievements.achievementId)).where(eq(userAchievements.userId, userId)),
  ]);
  return { ...user[0], ranks: rankRows.map((row) => row.rank), achievements: earned };
}

export async function createAuditLog(input: { actorId?: number; action: string; targetType: string; targetId?: number; metadata?: string }) {
  const db = await requireDb();
  const previous = await db.select({ recordHash: auditLogs.recordHash }).from(auditLogs).orderBy(desc(auditLogs.id)).limit(1);
  const crypto = await import("node:crypto");
  const payload = `${previous[0]?.recordHash ?? "GENESIS"}|${input.actorId ?? "system"}|${input.action}|${input.targetType}|${input.targetId ?? ""}|${input.metadata ?? ""}|${Date.now()}`;
  const recordHash = crypto.createHash("sha256").update(payload).digest("hex");
  await db.insert(auditLogs).values({ ...input, previousHash: previous[0]?.recordHash, recordHash });
}

export async function upsertBlock(blockerId: number, blockedId: number) {
  const db = await requireDb();
  const existing = await db.select().from(blocks).where(and(eq(blocks.blockerId, blockerId), eq(blocks.blockedId, blockedId))).limit(1);
  if (existing[0]) {
    await db.delete(blocks).where(eq(blocks.id, existing[0].id));
    return false;
  }
  await db.insert(blocks).values({ blockerId, blockedId });
  return true;
}

export async function hasPermission(userId: number, permissionKey: string) {
  const db = await requireDb();
  const user = await db.select({ role: users.role }).from(users).where(eq(users.id, userId)).limit(1);
  if (user[0]?.role === "admin") return true;
  const rows = await db.select({ id: permissions.id }).from(userRoles).innerJoin(rolePermissions, eq(rolePermissions.roleId, userRoles.roleId)).innerJoin(permissions, eq(permissions.id, rolePermissions.permissionId)).where(and(eq(userRoles.userId, userId), eq(permissions.key, permissionKey))).limit(1);
  return Boolean(rows[0]);
}

export async function listRolesAndPermissions() {
  const db = await requireDb();
  return db.select({ role: roles, permission: permissions }).from(roles).leftJoin(rolePermissions, eq(rolePermissions.roleId, roles.id)).leftJoin(permissions, eq(permissions.id, rolePermissions.permissionId)).orderBy(asc(roles.name), asc(permissions.label));
}

export async function getWikiArticle(id: number) {
  const db = await requireDb();
  const rows = await db.select({ article: wikiArticles, categoryName: wikiCategories.name, authorName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')` }).from(wikiArticles).innerJoin(wikiCategories, eq(wikiCategories.id, wikiArticles.categoryId)).leftJoin(users, eq(users.id, wikiArticles.authorId)).where(and(eq(wikiArticles.id, id), eq(wikiArticles.status, "published"))).limit(1);
  if (!rows[0]) return null;
  const revisions = await db.select({ revision: wikiRevisions.revision, editorId: wikiRevisions.editorId, createdAt: wikiRevisions.createdAt }).from(wikiRevisions).where(eq(wikiRevisions.articleId, id)).orderBy(desc(wikiRevisions.revision)).limit(10);
  return { ...rows[0], revisions };
}

export async function joinEvent(eventId: number, userId: number) {
  const db = await requireDb();
  const event = await db.select().from(events).where(and(eq(events.id, eventId), eq(events.status, "published"))).limit(1);
  if (!event[0]) throw new Error("Etkinlik bulunamadı.");
  const existing = await db.select().from(eventParticipants).where(and(eq(eventParticipants.eventId, eventId), eq(eventParticipants.userId, userId))).limit(1);
  if (existing[0]) {
    await db.delete(eventParticipants).where(eq(eventParticipants.id, existing[0].id));
    await db.update(events).set({ participantCount: sql`greatest(${events.participantCount} - 1, 0)` }).where(eq(events.id, eventId));
    return { joined: false };
  }
  await db.insert(eventParticipants).values({ eventId, userId });
  await db.update(events).set({ participantCount: sql`${events.participantCount} + 1` }).where(eq(events.id, eventId));
  return { joined: true };
}

export async function getCtfChallenge(id: number) {
  const db = await requireDb();
  const rows = await db.select({ id: ctfChallenges.id, title: ctfChallenges.title, slug: ctfChallenges.slug, description: ctfChallenges.description, category: ctfChallenges.category, difficulty: ctfChallenges.difficulty, points: ctfChallenges.points, hints: ctfChallenges.hints, solveCount: ctfChallenges.solveCount, hasAttachment: sql<boolean>`${ctfChallenges.attachmentKey} is not null`, status: ctfChallenges.status }).from(ctfChallenges).where(and(eq(ctfChallenges.id, id), eq(ctfChallenges.status, "published"))).limit(1);
  return rows[0] ?? null;
}

export async function getCtfLeaderboard() {
  const db = await requireDb();
  return db.select({ userId: users.id, name: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, solves: count(ctfSubmissions.id), score: sql<number>`coalesce(sum(case when ${ctfSubmissions.isCorrect} = true then ${ctfChallenges.points} else 0 end), 0)` }).from(ctfSubmissions).innerJoin(users, eq(users.id, ctfSubmissions.userId)).innerJoin(ctfChallenges, eq(ctfChallenges.id, ctfSubmissions.challengeId)).where(eq(ctfSubmissions.isCorrect, true)).groupBy(users.id, users.displayName, users.name).orderBy(desc(sql<number>`coalesce(sum(case when ${ctfSubmissions.isCorrect} = true then ${ctfChallenges.points} else 0 end), 0)`)).limit(20);
}

export async function listInbox(userId: number, query?: string) {
  const db = await requireDb();
  const condition = query ? and(eq(messages.isDeleted, false), or(like(messages.body, `%${query}%`), like(users.displayName, `%${query}%`), like(users.name, `%${query}%`))) : eq(messages.isDeleted, false);
  return db.select({ message: messages, senderName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')`, isRead: sql<boolean>`${conversationMembers.lastReadAt} is not null and ${messages.createdAt} <= ${conversationMembers.lastReadAt}` }).from(messages).innerJoin(conversationMembers, and(eq(conversationMembers.conversationId, messages.conversationId), eq(conversationMembers.userId, userId))).innerJoin(users, eq(users.id, messages.senderId)).where(condition).orderBy(desc(messages.createdAt)).limit(80);
}

export async function markMessagesRead(userId: number, conversationId: number) {
  const db = await requireDb();
  await db.update(conversationMembers).set({ lastReadAt: new Date() }).where(and(eq(conversationMembers.conversationId, conversationId), eq(conversationMembers.userId, userId)));
  return { success: true };
}

export async function deleteOwnMessage(userId: number, messageId: number) {
  const db = await requireDb();
  const result = await db.update(messages).set({ isDeleted: true }).where(and(eq(messages.id, messageId), eq(messages.senderId, userId)));
  await createAuditLog({ actorId: userId, action: "message_delete", targetType: "message", targetId: messageId });
  return { success: result[0].affectedRows > 0 };
}

export async function sendDirectMessage(input: { senderId: number; recipientId: number; body: string }) {
  const db = await requireDb();
  if (input.senderId === input.recipientId) throw new Error("Kendinize mesaj gönderemezsiniz.");
  const recipient = await db.select({ id: users.id, status: users.status }).from(users).where(eq(users.id, input.recipientId)).limit(1);
  if (!recipient[0] || recipient[0].status === "banned") throw new Error("Alıcı bulunamadı.");
  const blocked = await db.select().from(blocks).where(or(and(eq(blocks.blockerId, input.senderId), eq(blocks.blockedId, input.recipientId)), and(eq(blocks.blockerId, input.recipientId), eq(blocks.blockedId, input.senderId)))).limit(1);
  if (blocked[0]) throw new Error("Bu kullanıcıyla mesajlaşma engelli.");
  return db.transaction(async (tx) => {
    const senderConversations = await tx.select({ conversationId: conversationMembers.conversationId }).from(conversationMembers).where(eq(conversationMembers.userId, input.senderId));
    let conversationId: number | undefined;
    for (const candidate of senderConversations) {
      const shared = await tx.select({ id: conversationMembers.id }).from(conversationMembers).where(and(eq(conversationMembers.conversationId, candidate.conversationId), eq(conversationMembers.userId, input.recipientId))).limit(1);
      if (shared[0]) { conversationId = candidate.conversationId; break; }
    }
    if (!conversationId) {
      const conversation = await tx.insert(conversations).values({});
      conversationId = Number(conversation[0].insertId);
      await tx.insert(conversationMembers).values([{ conversationId, userId: input.senderId }, { conversationId, userId: input.recipientId }]);
    }
    const sent = await tx.insert(messages).values({ conversationId, senderId: input.senderId, body: input.body });
    await tx.insert(notifications).values({ userId: input.recipientId, actorId: input.senderId, type: "message", title: "Yeni özel mesaj", body: "Gelen kutunuzda yeni bir mesaj var.", href: "/messages" });
    return { id: Number(sent[0].insertId), conversationId };
  });
}

export async function updateProfile(input: { userId: number; username?: string; displayName?: string; bio?: string; socialLinks?: string; privacy?: "public" | "members" | "private"; showOnline?: boolean }) {
  const db = await requireDb();
  await db.update(users).set({ username: input.username, displayName: input.displayName, bio: input.bio }).where(eq(users.id, input.userId));
  await db.update(profiles).set({ socialLinks: input.socialLinks, privacy: input.privacy, showOnline: input.showOnline }).where(eq(profiles.userId, input.userId));
  await createAuditLog({ actorId: input.userId, action: "profile_update", targetType: "user", targetId: input.userId });
  return getProfile(input.userId);
}

const uploadRules = {
  avatar: { maxBytes: 2_000_000, mime: new Set(["image/png", "image/jpeg", "image/gif", "image/webp"]), extensions: new Set(["png", "jpg", "jpeg", "gif", "webp"]), visibility: "public" as const },
  cover: { maxBytes: 5_000_000, mime: new Set(["image/png", "image/jpeg", "image/webp"]), extensions: new Set(["png", "jpg", "jpeg", "webp"]), visibility: "public" as const },
  wiki_attachment: { maxBytes: 8_000_000, mime: new Set(["application/pdf", "text/plain", "image/png", "image/jpeg", "image/webp", "application/zip"]), extensions: new Set(["pdf", "txt", "png", "jpg", "jpeg", "webp", "zip"]), visibility: "members" as const },
  ctf_attachment: { maxBytes: 10_000_000, mime: new Set(["application/zip", "application/pdf", "text/plain", "image/png", "image/jpeg"]), extensions: new Set(["zip", "pdf", "txt", "png", "jpg", "jpeg"]), visibility: "members" as const },
};

export async function uploadUserObject(input: { userId: number; filename: string; mimeType: string; base64: string; purpose: "avatar" | "cover" | "wiki_attachment" | "ctf_attachment" }) {
  const rule = uploadRules[input.purpose];
  const extension = input.filename.toLowerCase().split(".").pop() || "";
  if (!rule.mime.has(input.mimeType) || !rule.extensions.has(extension)) throw new Error("Dosya türü bu alan için izinli değil.");
  const buffer = Buffer.from(input.base64, "base64");
  if (!buffer.length || buffer.length > rule.maxBytes) throw new Error("Dosya boyutu sınırları dışında.");
  if (!validateUploadBytes(input.mimeType, buffer)) throw new Error("Dosya imzası MIME türüyle eşleşmiyor.");
  if (input.mimeType === "text/plain" && buffer.includes(0)) throw new Error("Metin dosyası ikili veri içeriyor.");
  const safeFilename = input.filename.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-140);
  const stored = await storagePut(`${input.purpose}/${input.userId}/${safeFilename}`, buffer, input.mimeType);
  const db = await requireDb();
  await db.insert(storageObjects).values({ ownerId: input.userId, objectKey: stored.key, url: stored.url, filename: safeFilename, mimeType: input.mimeType, sizeBytes: buffer.length, purpose: input.purpose, visibility: rule.visibility });
  if (input.purpose === "avatar") await db.update(users).set({ avatarUrl: stored.url }).where(eq(users.id, input.userId));
  if (input.purpose === "cover") await db.update(users).set({ coverUrl: stored.url }).where(eq(users.id, input.userId));
  await createAuditLog({ actorId: input.userId, action: "object_upload", targetType: "storage_object", metadata: JSON.stringify({ purpose: input.purpose, mimeType: input.mimeType, sizeBytes: buffer.length }) });
  return stored;
}

export async function assignUserRole(input: { userId: number; roleId: number; assignedBy: number }) {
  const db = await requireDb();
  const target = await db.select({ id: users.id }).from(users).where(eq(users.id, input.userId)).limit(1);
  const role = await db.select({ id: roles.id, key: roles.key }).from(roles).where(eq(roles.id, input.roleId)).limit(1);
  if (!target[0] || !role[0]) throw new Error("Kullanıcı veya rol bulunamadı.");
  await db.insert(userRoles).values(input).onDuplicateKeyUpdate({ set: { assignedBy: input.assignedBy } });
  await createAuditLog({ actorId: input.assignedBy, action: "role_assign", targetType: "user", targetId: input.userId, metadata: JSON.stringify({ roleId: input.roleId, roleKey: role[0].key }) });
  return { success: true };
}

export async function setRolePermission(input: { roleId: number; permissionId: number; enabled: boolean; actorId: number }) {
  const db = await requireDb();
  if (input.enabled) await db.insert(rolePermissions).values({ roleId: input.roleId, permissionId: input.permissionId }).onDuplicateKeyUpdate({ set: { roleId: input.roleId } });
  else await db.delete(rolePermissions).where(and(eq(rolePermissions.roleId, input.roleId), eq(rolePermissions.permissionId, input.permissionId)));
  await createAuditLog({ actorId: input.actorId, action: input.enabled ? "permission_grant" : "permission_revoke", targetType: "role", targetId: input.roleId, metadata: JSON.stringify({ permissionId: input.permissionId }) });
  return { success: true };
}

export async function assignUserRank(input: { userId: number; rankId: number; assignedBy?: number }) {
  const db = await requireDb();
  const rank = await db.select({ id: ranks.id, name: ranks.name }).from(ranks).where(eq(ranks.id, input.rankId)).limit(1);
  if (!rank[0]) throw new Error("Rank bulunamadı.");
  await db.insert(userRanks).values({ userId: input.userId, rankId: input.rankId, assignedBy: input.assignedBy }).onDuplicateKeyUpdate({ set: { assignedBy: input.assignedBy } });
  await db.insert(notifications).values({ userId: input.userId, actorId: input.assignedBy, type: "rank", title: "Yeni rank kazandınız", body: `${rank[0].name} rankı profilinize işlendi.`, href: `/members/${input.userId}` });
  await createAuditLog({ actorId: input.assignedBy, action: "rank_assign", targetType: "user", targetId: input.userId, metadata: JSON.stringify({ rankId: input.rankId }) });
  return { success: true };
}

export async function grantAchievement(input: { userId: number; achievementId: number; progress?: number; actorId?: number }) {
  const db = await requireDb();
  const achievement = await db.select({ id: achievements.id, name: achievements.name }).from(achievements).where(eq(achievements.id, input.achievementId)).limit(1);
  if (!achievement[0]) throw new Error("Achievement bulunamadı.");
  const existing = await db.select().from(userAchievements).where(and(eq(userAchievements.userId, input.userId), eq(userAchievements.achievementId, input.achievementId))).limit(1);
  const unlockedAt = existing[0]?.unlockedAt ?? new Date();
  await db.insert(userAchievements).values({ userId: input.userId, achievementId: input.achievementId, progress: input.progress ?? 100, unlockedAt }).onDuplicateKeyUpdate({ set: { progress: input.progress ?? 100, unlockedAt } });
  if (!existing[0]?.unlockedAt) await db.insert(notifications).values({ userId: input.userId, actorId: input.actorId, type: "achievement", title: "Yeni başarım açıldı", body: `${achievement[0].name} başarımını kazandınız.`, href: `/members/${input.userId}` });
  await createAuditLog({ actorId: input.actorId, action: "achievement_grant", targetType: "user", targetId: input.userId, metadata: JSON.stringify({ achievementId: input.achievementId }) });
  return { success: true, unlocked: !existing[0]?.unlockedAt };
}

export async function createAnnouncement(input: { authorId: number; title: string; content: string; priority: "normal" | "high" | "critical"; visibility: "public" | "members" | "staff" }) {
  const db = await requireDb();
  const inserted = await db.insert(announcements).values(input);
  const announcementId = Number(inserted[0].insertId);
  if (input.visibility !== "staff") {
    const recipients = await db.select({ id: users.id }).from(users).where(eq(users.status, "active"));
    if (recipients.length) await db.insert(notifications).values(recipients.map((recipient) => ({ userId: recipient.id, actorId: input.authorId, type: "announcement" as const, title: input.title, body: input.content.slice(0, 240), href: input.visibility === "public" ? `/announcements/${announcementId}` : "/notifications" })));
  }
  await createAuditLog({ actorId: input.authorId, action: "announcement_publish", targetType: "announcement", targetId: announcementId, metadata: JSON.stringify({ priority: input.priority, visibility: input.visibility }) });
  return { id: announcementId };
}

export async function moderateThread(input: { threadId: number; moderatorId: number; action: "lock" | "unlock" | "pin" | "unpin" | "move" | "edit"; forumId?: number; title?: string }) {
  const db = await requireDb();
  const thread = await db.select().from(threads).where(eq(threads.id, input.threadId)).limit(1);
  if (!thread[0]) throw new Error("Konu bulunamadı.");
  const changes: Partial<typeof threads.$inferInsert> = {};
  if (input.action === "lock") changes.status = "locked";
  if (input.action === "unlock") changes.status = "open";
  if (input.action === "pin") changes.isPinned = true;
  if (input.action === "unpin") changes.isPinned = false;
  if (input.action === "move" && input.forumId) changes.forumId = input.forumId;
  if (input.action === "edit" && input.title) changes.title = input.title;
  if (Object.keys(changes).length) await db.update(threads).set(changes).where(eq(threads.id, input.threadId));
  await createAuditLog({ actorId: input.moderatorId, action: `thread_${input.action}`, targetType: "thread", targetId: input.threadId, metadata: JSON.stringify({ forumId: input.forumId, title: input.title }) });
  return { success: true };
}

export async function moderatePost(input: { postId: number; moderatorId: number; action: "delete" | "restore" | "edit"; body?: string }) {
  const db = await requireDb();
  const post = await db.select().from(posts).where(eq(posts.id, input.postId)).limit(1);
  if (!post[0]) throw new Error("Gönderi bulunamadı.");
  const changes: Partial<typeof posts.$inferInsert> = {};
  if (input.action === "delete") changes.isDeleted = true;
  if (input.action === "restore") changes.isDeleted = false;
  if (input.action === "edit" && input.body) { changes.body = input.body; changes.isEdited = true; changes.editedAt = new Date(); }
  if (Object.keys(changes).length) await db.update(posts).set(changes).where(eq(posts.id, input.postId));
  await createAuditLog({ actorId: input.moderatorId, action: `post_${input.action}`, targetType: "post", targetId: input.postId, metadata: JSON.stringify({ bodyChanged: input.action === "edit" }) });
  return { success: true };
}

export async function resolveStorageObject(input: { objectId: number; viewerId: number; viewerRole: "user" | "admin" }) {
  const db = await requireDb();
  const object = await db.select().from(storageObjects).where(eq(storageObjects.id, input.objectId)).limit(1);
  if (!object[0]) throw new Error("Dosya bulunamadı.");
  const allowed = object[0].visibility === "public" || object[0].ownerId === input.viewerId || input.viewerRole === "admin" || object[0].visibility === "members";
  if (!allowed) throw new Error("Bu dosyaya erişim yetkiniz yok.");
  return { id: object[0].id, filename: object[0].filename, mimeType: object[0].mimeType, sizeBytes: object[0].sizeBytes, url: await storageGetSignedUrl(object[0].objectKey) };
}

export async function getAnnouncement(id: number) {
  const db = await requireDb();
  const row = await db.select({ announcement: announcements, authorName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')` }).from(announcements).leftJoin(users, eq(users.id, announcements.authorId)).where(and(eq(announcements.id, id), eq(announcements.visibility, "public"))).limit(1);
  return row[0] ?? null;
}


export async function listCtfWriteups(challengeId: number) {
  const db = await requireDb();
  return db.select({ writeup: ctfWriteups, authorName: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')` }).from(ctfWriteups).innerJoin(users, eq(users.id, ctfWriteups.authorId)).where(and(eq(ctfWriteups.challengeId, challengeId), eq(ctfWriteups.status, "published"))).orderBy(desc(ctfWriteups.updatedAt)).limit(50);
}

export async function createCtfWriteup(input: { challengeId: number; authorId: number; title: string; content: string }) {
  const db = await requireDb();
  const safeContent = sanitizeForumBody(input.content, 20_000);
  const result = await db.insert(ctfWriteups).values({ challengeId: input.challengeId, authorId: input.authorId, title: input.title.trim().slice(0, 180), content: safeContent, status: "published" });
  const id = Number(result[0].insertId);
  await createAuditLog({ actorId: input.authorId, action: "ctf_writeup_create", targetType: "ctf_writeup", targetId: id });
  return { id };
}


export async function resolveCtfAttachment(input: { challengeId: number; viewerId: number; viewerRole: "user" | "admin" }) {
  const db = await requireDb();
  const challenge = await db.select({ attachmentKey: ctfChallenges.attachmentKey }).from(ctfChallenges).where(and(eq(ctfChallenges.id, input.challengeId), eq(ctfChallenges.status, "published"))).limit(1);
  const key = challenge[0]?.attachmentKey;
  if (!key) return null;
  const object = await db.select({ id: storageObjects.id, filename: storageObjects.filename, mimeType: storageObjects.mimeType, sizeBytes: storageObjects.sizeBytes, objectKey: storageObjects.objectKey, visibility: storageObjects.visibility, ownerId: storageObjects.ownerId }).from(storageObjects).where(eq(storageObjects.objectKey, key)).limit(1);
  if (!object[0]) return null;
  const allowed = object[0].visibility === "public" || object[0].visibility === "members" || object[0].ownerId === input.viewerId || input.viewerRole === "admin";
  if (!allowed) throw new Error("Bu dosyaya erişim yetkiniz yok.");
  return { id: object[0].id, filename: object[0].filename, mimeType: object[0].mimeType, sizeBytes: object[0].sizeBytes, url: await storageGetSignedUrl(object[0].objectKey) };
}


export async function refreshUserProgress(userId: number) {
  const db = await requireDb();
  const [profileRow, userThreadCount, activeRanks, activeAchievements, existingRanks, existingAchievements] = await Promise.all([
    db.select({ postCount: profiles.postCount, reactionCount: profiles.reactionCount }).from(profiles).where(eq(profiles.userId, userId)).limit(1),
    db.select({ value: count() }).from(threads).where(eq(threads.authorId, userId)),
    db.select().from(ranks).where(eq(ranks.isActive, true)).orderBy(asc(ranks.sortOrder)),
    db.select().from(achievements).where(eq(achievements.isActive, true)),
    db.select({ rankId: userRanks.rankId }).from(userRanks).where(eq(userRanks.userId, userId)),
    db.select({ achievementId: userAchievements.achievementId, unlockedAt: userAchievements.unlockedAt }).from(userAchievements).where(eq(userAchievements.userId, userId)),
  ]);
  const postCount = Number(profileRow[0]?.postCount ?? 0);
  const reactionCount = Number(profileRow[0]?.reactionCount ?? 0);
  const threadCount = Number(userThreadCount[0]?.value ?? 0);
  const oldRankIds = new Set(existingRanks.map((row) => row.rankId));
  for (const rank of activeRanks.filter((candidate) => candidate.minPosts <= postCount)) {
    await db.insert(userRanks).values({ userId, rankId: rank.id }).onDuplicateKeyUpdate({ set: { userId } });
    if (!oldRankIds.has(rank.id)) await db.insert(notifications).values({ userId, type: "rank", title: "Yeni rank açıldı", body: `${rank.name} rank'ına ulaştınız.`, href: `/members/${userId}` });
  }
  const oldAchievements = new Map(existingAchievements.map((row) => [row.achievementId, row.unlockedAt]));
  for (const achievement of activeAchievements) {
    const progress = achievement.requirementType === "posts" ? postCount : achievement.requirementType === "threads" ? threadCount : achievement.requirementType === "reactions" ? reactionCount : 0;
    const unlocked = progress >= achievement.requirementValue;
    await db.insert(userAchievements).values({ userId, achievementId: achievement.id, progress, unlockedAt: unlocked ? new Date() : null }).onDuplicateKeyUpdate({ set: { progress, unlockedAt: unlocked ? new Date() : null } });
    if (unlocked && !oldAchievements.get(achievement.id)) await db.insert(notifications).values({ userId, type: "achievement", title: "Yeni başarım açıldı", body: `${achievement.name} başarımını açtınız.`, href: `/members/${userId}` });
  }
}


export async function assignForumModerator(input: { forumId: number; userId: number; assignedBy: number }) {
  const db = await requireDb();
  await db.insert(forumModerators).values(input).onDuplicateKeyUpdate({ set: { assignedBy: input.assignedBy } });
  await createAuditLog({ actorId: input.assignedBy, action: "forum_moderator_assign", targetType: "forum", targetId: input.forumId, metadata: JSON.stringify({ userId: input.userId }) });
  return { success: true };
}

export async function setForumPermission(input: { forumId: number; permissionId: number; enabled: boolean; actorId: number }) {
  const db = await requireDb();
  await db.insert(forumPermissions).values({ forumId: input.forumId, permissionId: input.permissionId, enabled: input.enabled }).onDuplicateKeyUpdate({ set: { enabled: input.enabled } });
  await createAuditLog({ actorId: input.actorId, action: "forum_permission_set", targetType: "forum", targetId: input.forumId, metadata: JSON.stringify({ permissionId: input.permissionId, enabled: input.enabled }) });
  return { success: true };
}

export async function listForumAccess(forumId: number) {
  const db = await requireDb();
  const [moderators, overrides] = await Promise.all([
    db.select({ userId: forumModerators.userId, name: sql<string>`coalesce(${users.displayName}, ${users.name}, 'İsimsiz üye')` }).from(forumModerators).innerJoin(users, eq(users.id, forumModerators.userId)).where(eq(forumModerators.forumId, forumId)),
    db.select({ permissionId: forumPermissions.permissionId, permissionKey: permissions.key, enabled: forumPermissions.enabled }).from(forumPermissions).innerJoin(permissions, eq(permissions.id, forumPermissions.permissionId)).where(eq(forumPermissions.forumId, forumId)),
  ]);
  return { moderators, overrides };
}


export async function updateOwnPost(input: { userId: number; postId: number; body: string }) {
  const db = await requireDb();
  const safeBody = sanitizeForumBody(input.body, 30_000);
  const result = await db.update(posts).set({ body: safeBody, isEdited: true, editedAt: new Date() }).where(and(eq(posts.id, input.postId), eq(posts.authorId, input.userId), eq(posts.isDeleted, false)));
  if (!result[0].affectedRows) throw new Error("Gönderi bulunamadı veya düzenleme yetkiniz yok.");
  await createAuditLog({ actorId: input.userId, action: "post_edit_own", targetType: "post", targetId: input.postId });
  return { success: true };
}

export async function deleteOwnPost(input: { userId: number; postId: number }) {
  const db = await requireDb();
  const result = await db.update(posts).set({ isDeleted: true }).where(and(eq(posts.id, input.postId), eq(posts.authorId, input.userId), eq(posts.isDeleted, false)));
  if (result[0].affectedRows) await createAuditLog({ actorId: input.userId, action: "post_delete_own", targetType: "post", targetId: input.postId });
  return { success: result[0].affectedRows > 0 };
}


export function validateUploadBytes(mimeType: string, buffer: Buffer) {
  const signatures: Record<string, (data: Buffer) => boolean> = {
    "image/png": (data) => data.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])),
    "image/jpeg": (data) => data.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff])),
    "image/gif": (data) => data.subarray(0, 4).toString() === "GIF8",
    "image/webp": (data) => data.subarray(0, 4).toString() === "RIFF" && data.subarray(8, 12).toString() === "WEBP",
    "application/pdf": (data) => data.subarray(0, 5).toString() === "%PDF-",
    "application/zip": (data) => data.subarray(0, 4).equals(Buffer.from([0x50, 0x4b, 0x03, 0x04])),
  };
  return !signatures[mimeType] || signatures[mimeType](buffer);
}


export async function createWikiArticle(input: { categoryId: number; authorId: number; title: string; summary: string; content: string; status: "draft" | "published" }) {
  const db = await requireDb();
  const safeTitle = input.title.trim().slice(0, 180);
  const safeSummary = sanitizeForumBody(input.summary, 500);
  const safeContent = sanitizeForumBody(input.content, 50_000);
  const slug = `${safeTitle.toLowerCase().replace(/[^a-z0-9ğüşöçıİĞÜŞÖÇ]+/gi, "-").replace(/^-|-$/g, "").slice(0, 150) || "makale"}-${Date.now().toString(36)}`;
  const inserted = await db.insert(wikiArticles).values({ categoryId: input.categoryId, authorId: input.authorId, title: safeTitle, slug, summary: safeSummary, content: safeContent, status: input.status, revision: 1 });
  const id = Number(inserted[0].insertId);
  await db.insert(wikiRevisions).values({ articleId: id, editorId: input.authorId, revision: 1, title: safeTitle, content: safeContent });
  await createAuditLog({ actorId: input.authorId, action: "wiki_article_create", targetType: "wiki", targetId: id, metadata: JSON.stringify({ status: input.status }) });
  return { id };
}
