export type Locale = "tr" | "en";

export const messages = {
  tr: {
    nav: { home: "Merkez", forums: "Forumlar", members: "Üyeler", wiki: "Bilgi Merkezi", ctf: "CTF", events: "Etkinlikler", leaderboard: "Liderlik" },
    actions: { login: "Giriş", logout: "Oturumu kapat", save: "Kaydet", cancel: "Vazgeç", search: "Ara", next: "Sonraki", previous: "Önceki" },
    states: { loading: "Yükleniyor", empty: "Henüz kayıt yok.", error: "Bir hata oluştu.", forbidden: "Bu işlem için yetkiniz bulunmuyor." },
  },
  en: {
    nav: { home: "Home", forums: "Forums", members: "Members", wiki: "Knowledge Base", ctf: "CTF", events: "Events", leaderboard: "Leaderboard" },
    actions: { login: "Sign in", logout: "Sign out", save: "Save", cancel: "Cancel", search: "Search", next: "Next", previous: "Previous" },
    states: { loading: "Loading", empty: "No records yet.", error: "Something went wrong.", forbidden: "You do not have permission for this action." },
  },
} as const;

export function translate(locale: Locale, section: keyof typeof messages.tr, key: string) {
  const value = messages[locale][section] as Record<string, string>;
  return value[key] ?? messages.tr[section][key as keyof typeof messages.tr[typeof section]] ?? key;
}
