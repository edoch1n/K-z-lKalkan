# Route and Link Audit

| Surface | Route | Status | Notes |
| --- | --- | --- | --- |
| Community home | `/` | Verified | Live stats, navigation and announcement panel render |
| Forums | `/forums` | Verified | Empty-state, pagination controls and forum taxonomy render |
| Knowledge base | `/wiki` | Verified | Seeded published article renders |
| CTF | `/ctf` | Verified | Seeded challenge renders without exposing the flag |
| Events | `/events` | Verified | Seeded published event and join/leave toggle render |
| Leaderboard | `/leaderboard` | Verified | All-time, weekly and monthly controls render |
| Messages | `/messages` | Verified | Search, empty inbox and send form render |
| Notifications | `/notifications` | Implemented | Protected list/read flow; member-only announcement links return here |
| Announcement detail | `/announcements/:id` | Implemented | Public announcement detail route added for public notifications |
| Member profile | `/members/:id` | Implemented | Used by member and rank/achievement notification links |
| Settings | `/settings` | Implemented | Profile and avatar upload flow |
| Admin | `/admin` | Verified | Separate dashboard, RBAC, reports, content moderation and live snapshot queries |
| Not found | `/404` and fallback | Implemented | Safe Turkish 404 surface |
| Error fallback | Error boundary | Implemented | Safe Turkish 500 surface hides stack traces |

Final log review found no new duplicate-key warning after the dashboard sidebar key fix. The initial anonymous OAuth `Missing session cookie` line is expected before authentication; authenticated RPC requests use the session bearer and return HTTP 200.
