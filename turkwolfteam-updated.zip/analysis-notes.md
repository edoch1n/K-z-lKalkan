# TURKWOLFTEAM inceleme notları

## Kaynaklar ve sınırlar

Bu çalışma mevcut `/home/ubuntu/upload/turkwolfteam.zip` arşivinin açılmış kopyası üzerinde yürütülür. Orijinal ZIP korunur; yeni bir proje oluşturulmaz. Arşivdeki `forum.png`, kompakt ve bilgi yoğun klasik forum referansıdır: ince header, belirgin kategori başlıkları, forum satırlarında Forum/Konu/Mesaj/Son Mesaj hizası, sağda Latest Posts paneli, küçük avatarlar ve düşük görsel gürültü.

## Tespit edilen stack

| Alan | Mevcut yapı |
| --- | --- |
| Frontend | React 19, Vite 7, TypeScript, Tailwind CSS 4, Wouter |
| Backend | Express, tRPC 11 |
| Veri | Drizzle ORM, MySQL/MariaDB uyumlu `mysql2` |
| Kimlik | Manus OAuth tabanlı mevcut auth hook ve server prosedürleri |
| UI | Tailwind utility sınıfları, Radix bileşenleri, Lucide ikonları |
| Test/build | `pnpm check`, `pnpm test`, `pnpm build` |

## Korunacak canlı çekirdek

`server/routers.ts`, `server/db.ts` ve `drizzle/schema.ts` gerçek forum, kategori, konu, gönderi, reaksiyon, bildirim, mesaj, profil, CTF, wiki, etkinlik, leaderboard, moderasyon, RBAC ve admin işlemlerini taşıyor. UI refactor sırasında bu tRPC prosedür isimleri ve mutation/query akışları korunacak; kategori ve istatistikler hard-code edilmeyecek.

## İlk doğrulama

Bağımlılıklar `pnpm install --frozen-lockfile` ile kuruldu. Mevcut kopyada `pnpm check` ve `pnpm build` başarılı. Build sırasında `client/index.html` içindeki tanımsız analytics placeholder'ları ve 500 KB üzeri JS chunk uyarısı var; bunlar daha sonra temizlenecek/iyileştirilecek. Mevcut kaynakta `CommunityLayout`, `Home`, `Forums`, `Thread`, `Profile`, `Members` ve `Admin` mevcut ortak tRPC/auth akışlarına bağlı.

## UI/UX refactor kararı

1. Aşırı cyberpunk görünüm azaltılacak: lime neon primary, scanline, grid overlay, sürekli glitch, ağır blur ve büyük hero dili kaldırılacak veya yalnızca küçük marka detaylarında tutulacak.
2. Ortak görsel sistem koyu forum yüzeyi üzerine kurulacak: `#0B0B0B`, `#101010`, `#151515`, `#202020`, gri tipografi ve kontrollü cyan `#168DCC`/`#1CA7E0`.
3. Community shell; kompakt header, desktop'ta forum-merkezli içerik + sağ sidebar, mobilde hamburger menü ve stacked içerik olacak şekilde düzenlenecek.
4. Home ve Forums, referansın bilgi yoğun forum index yaklaşımına en yakın biçimde yeniden yazılacak; son tartışmalar, kategori/forum satırları ve sağ sidebar canlı API verisinden okunacak.
5. Thread klasik iki kolonlu forum post düzenine; Profile ve Members kompakt topluluk listelerine dönüştürülecek. Mesajlar, bildirimler, Explore modülleri ve Admin ortak panel token'larıyla uyumlandırılacak.
6. Responsive kurallarında özellikle 320–414 px mobil genişliklerde yatay taşma engellenecek; thread kod blokları, uzun URL'ler, tablolar ve forum metadata mobilde yeniden akacak.
7. `prefers-reduced-motion`, görünür focus, semantik navigasyon ve aria etiketleri korunacak/artırılacak.

## Üretim taşınabilirliği notu

Mevcut DB katmanı MySQL bağlantısını `DATABASE_URL` ile destekliyor; bu Hostinger için uygundur. Buna karşılık storage ve bazı auth/asset yolları Manus Forge/preview varsayımlarına bağlıdır. Bu ilk refactor'da çalışan auth ve API çekirdeği bozulmadan bırakılır; `.env.example`, analytics placeholder temizliği ve Hostinger geçiş notları ayrıca hazırlanır. Gerçek secret değerleri repoya eklenmez.
