# Runtime, Deployment and Backup Notes

TURKWOLFTEAM relies on the environment values injected by the managed runtime. Required names are documented in the scaffold README and include `DATABASE_URL`, `JWT_SECRET`, Manus OAuth variables, Forge storage/notification variables, owner identity values, and analytics identifiers. Real values must be entered through the project secrets manager and must never be committed.

The project is compatible with the managed Node autoscale runtime. The server does not spawn workers or depend on local persistent files. Database migrations are generated from `drizzle/schema.ts`, reviewed, and applied through the managed database migration flow. Object bytes are stored in S3-compatible object storage; the database stores only ownership and access metadata.

Back up the database before destructive schema work, retain migration files in version control, and export storage metadata together with object-storage lifecycle/versioning policies. Restore order is database schema, reference/system data, user metadata, then object objects. Audit records should be retained according to the operator's governance policy.

For production abuse prevention across multiple autoscale instances, replace the in-process rate limiter with a shared Redis or database-backed limiter. Before public launch, configure a custom domain, enforce HTTPS, enable database TLS, review object-storage retention, and set alert routing for owner notifications.
