# QA Notes

- The scaffolded DashboardLayout is available and is used by the separate `/admin` experience, while public community routes use a custom responsive shell.
- The current relational schema includes users, profiles, roles, permissions, forums, threads, posts, reactions, mentions, notifications, conversations, messages, blocks, reports, moderation logs, achievements, wiki, events, CTF, and storage metadata.
- Visual verification confirmed the dark cyber-wolf shell, cyan/lime accent hierarchy, CRT scanlines, glitch headline, responsive three-column desktop layout, empty states, and live owner session data.
- A runtime issue in `ctf.leaderboard` was diagnosed: MySQL could not order by the unaliased computed `score` field. The query was changed to order by the full aggregate expression.

## Visual QA checkpoint

Desktop capture shows a clear three-column public shell with a high-contrast hero, accessible focusable navigation, empty-state treatment, and live database metrics. Mobile capture at 390px shows the hamburger shell, single-column cards, full-width forum CTA, compact event card, and readable settings form without horizontal overflow. Seeded event content renders with localized date/time and the join/leave action.

## Browser smoke checks

The live preview loaded `/` and `/ctf` successfully with HTTP-backed data. The CTF route renders the seeded challenge, category, points, difficulty, solve count, and server-only validation notice. The browser-visible page contains no flag hash or raw flag value.

## Final remediation QA — 2026-09-02

TypeScript validation, the Vitest suite, and the production build all pass. The suite contains 5 test files and 11 passing tests, including cross-site logout rejection, forum-body sanitization, CTF constant-time verification, RBAC denial, rate limits, and GIF magic-byte upload acceptance/rejection.

Desktop screenshots were captured for `/`, `/forums`, `/events`, `/ctf`, `/wiki`, `/search`, and `/admin`. The public routes show the Turkish-first cyber-wolf visual system, live seeded records, event countdown/location presentation, CTF challenge surface, wiki surface, and cross-module search. The admin route shows live database metrics, audit-chain status, moderation tabs, and RBAC controls without the prior duplicate-key warning.

Known operator-only follow-ups are documented rather than hidden: run a formal axe/pa11y scan against the production domain, test with a screen reader, and use a shared rate-limit backend for multi-instance production abuse prevention.

## 2026-09-02 UI refactor doğrulaması

Geliştirme sunucusu `http://localhost:3000/` üzerinde ayağa kalktı. Ana sayfa yeni kompakt header, sol navigasyon, duyuru bandı, içerik alanı ve sağ sidebar ile görsel olarak yüklendi. Veritabanı ortam değişkenleri sağlanmadığı için `home.overview` sorgusu `Database unavailable` döndü; arayüz kontrollü biçimde `Forum verisi alınamadı` mesajını gösterdi ve uygulama çökmüyor. Sunucu başlangıcında OAuth ortam değişkeni eksik uyarısı beklenen yerel geliştirme durumudur.

Build sonrası analytics placeholder uyarısı kaldırıldı; güncel build'de yalnızca büyük JS chunk optimizasyon uyarısı kaldı.

## Forum index desktop checkpoint

`/forums` görsel olarak kompakt header, sol kategori navigasyonu, konu arama çubuğu, konu/yanıt/görüntülenme/son mesaj başlıkları ve sağ sidebar ile yükleniyor. Veritabanı yokken liste alanı kontrollü skeleton/boş alan durumunda kalıyor. Tarayıcı ölçümünde viewport 1280 px, document/body genişliği 1280 px; yatay taşma yok.
