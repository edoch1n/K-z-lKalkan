import { Bell, ChevronRight, MessageSquare, Users } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";

const formatter = new Intl.NumberFormat("tr-TR");

function ForumRow({ forum }: { forum: { id: number; name: string; description?: string | null; threadCount: number; postCount: number; lastPostAt?: Date | string | null } }) {
  return (
    <Link href={`/forums/${forum.id}`} className="forum-row group">
      <div className="forum-row-main">
        <span className="forum-icon"><MessageSquare size={15} /></span>
        <div className="forum-row-copy">
          <div className="forum-row-title group-hover:text-accent">{forum.name}</div>
          <div className="forum-row-description">{forum.description || "Topluluk tartışmaları ve paylaşımlar."}</div>
        </div>
      </div>
      <div className="forum-count">{formatter.format(forum.threadCount)}</div>
      <div className="forum-count">{formatter.format(forum.postCount)}</div>
      <div className="forum-last-post"><strong>{forum.lastPostAt ? "Son hareket" : "Henüz mesaj yok"}</strong><span>{forum.lastPostAt ? new Date(forum.lastPostAt).toLocaleDateString("tr-TR") : "Topluluğun ilk konusunu açın"}</span></div>
      <div className="forum-row-meta"><strong>{formatter.format(forum.threadCount)} konu</strong><span>·</span><span>{formatter.format(forum.postCount)} mesaj</span><span>·</span><span>{forum.lastPostAt ? `Son hareket ${new Date(forum.lastPostAt).toLocaleDateString("tr-TR")}` : "Yeni forum"}</span></div>
    </Link>
  );
}

export default function Home() {
  const { data, isLoading, isError } = trpc.home.overview.useQuery();

  return (
    <div className="forum-page space-y-5">
      <div className="forum-breadcrumb"><Link href="/">Ana Sayfa</Link><ChevronRight size={13} /><span>Forumlar</span></div>
      <section className="forum-panel flex flex-col gap-3 border-l-2 border-l-accent px-4 py-3 sm:flex-row sm:items-center sm:justify-between sm:px-5">
        <div className="flex items-start gap-3"><Bell size={16} className="mt-0.5 shrink-0 text-accent" /><div><div className="font-mono text-[10px] uppercase tracking-[.1em] text-accent">Duyuru</div><p className="mt-1 text-sm text-secondary-foreground">TURKWOLFTEAM topluluğuna hoş geldiniz. Teknik bilginizi paylaşın, birlikte üretin.</p></div></div>
        <Link href="/announcements/1" className="shrink-0 font-mono text-[10px] uppercase tracking-[.1em] text-accent hover:text-white">Duyurular <ChevronRight className="inline" size={13} /></Link>
      </section>

      {isError ? <div className="forum-panel p-6 text-sm text-destructive">Forum verisi alınamadı. Lütfen daha sonra tekrar deneyin.</div> : <>
        <section>
          <div className="mb-2 flex items-end justify-between gap-3"><div><div className="kicker mb-1">/ topluluk forumu</div><h1 className="forum-title font-display uppercase text-white">Forumlar</h1></div><Link href="/forums" className="hidden font-mono text-[10px] uppercase tracking-[.1em] text-accent hover:text-white sm:block">Tüm konular <ChevronRight className="inline" size={13} /></Link></div>
          {isLoading ? <div className="forum-panel divide-y divide-border">{Array.from({ length: 5 }).map((_, index) => <div key={index} className="h-[66px] animate-pulse bg-white/[.03]" />)}</div> : data?.categories?.length ? <div className="space-y-4">{data.categories.map((category) => <div key={category.id}><div className="forum-section-title">{category.name}<span className="ml-2 font-normal text-muted-foreground">{category.description || ""}</span></div><div className="forum-table-head"><span>Forum</span><span className="text-center">Konular</span><span className="text-center">Mesajlar</span><span>Son Mesaj</span></div>{category.forums.length ? category.forums.map((forum) => <ForumRow key={forum.id} forum={forum} />) : <div className="forum-panel rounded-t-none p-4 text-xs text-muted-foreground">Bu kategoride henüz forum bulunmuyor.</div>}</div>)}</div> : <div className="forum-panel p-8 text-center text-sm text-muted-foreground">Henüz görünür forum kategorisi bulunmuyor.</div>}
        </section>

        <section className="grid gap-3 border-t border-border pt-4 sm:grid-cols-3"><div className="forum-panel flex items-center gap-3 p-3"><MessageSquare size={17} className="text-accent" /><div><div className="font-mono text-[9px] uppercase text-muted-foreground">Toplam konu</div><div className="font-display text-xl text-white">{data ? formatter.format(data.stats.threads) : "—"}</div></div></div><div className="forum-panel flex items-center gap-3 p-3"><MessageSquare size={17} className="text-accent" /><div><div className="font-mono text-[9px] uppercase text-muted-foreground">Toplam mesaj</div><div className="font-display text-xl text-white">{data ? formatter.format(data.stats.posts) : "—"}</div></div></div><div className="forum-panel flex items-center gap-3 p-3"><Users size={17} className="text-accent" /><div><div className="font-mono text-[9px] uppercase text-muted-foreground">Aktif üye</div><div className="font-display text-xl text-white">{data ? formatter.format(data.stats.online) : "—"}</div></div></div></section>
      </>}
    </div>
  );
}
