import { Bell, CalendarDays, ShieldCheck } from "lucide-react";
import { Link, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";

export default function Announcement() {
  const [, params] = useRoute("/announcements/:id");
  const id = Number(params?.id);
  const announcement = trpc.announcements.get.useQuery({ id }, { enabled: Number.isInteger(id) && id > 0 });
  if (announcement.isLoading) return <div className="panel h-64 animate-pulse bg-white/5" />;
  if (!announcement.data) return <div className="panel p-10 text-center"><Bell className="mx-auto mb-3 text-muted-foreground/50" size={28} /><h1 className="font-display text-3xl uppercase text-white">Duyuru bulunamadı</h1><Link href="/" className="mt-4 inline-flex text-sm text-primary">Merkeze dön</Link></div>;
  const { announcement: item, authorName } = announcement.data;
  return <article className="panel mx-auto max-w-3xl overflow-hidden"><div className="border-b border-border/70 bg-primary/[.04] p-6 md:p-8"><div className="kicker mb-3">/ control channel · {item.priority}</div><h1 className="font-display text-4xl uppercase tracking-[.03em] text-white md:text-5xl">{item.title}</h1><div className="mt-4 flex flex-wrap items-center gap-4 font-mono text-[10px] uppercase text-muted-foreground"><span className="flex items-center gap-1.5"><CalendarDays size={13} className="text-primary" /> {new Date(item.createdAt).toLocaleString("tr-TR")}</span><span className="flex items-center gap-1.5"><ShieldCheck size={13} className="text-accent" /> {authorName}</span></div></div><div className="prose prose-invert max-w-none p-6 text-sm leading-7 text-secondary-foreground md:p-8"><p>{item.content}</p></div></article>;
}
