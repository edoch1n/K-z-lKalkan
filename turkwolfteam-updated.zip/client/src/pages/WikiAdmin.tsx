import { useState } from "react";
import { Link } from "wouter";
import { BookOpen, Save } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

export default function WikiAdmin() {
  const { user } = useAuth();
  const [categoryId, setCategoryId] = useState("1");
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");
  const [content, setContent] = useState("");
  const create = trpc.wiki.adminCreate.useMutation({ onSuccess: (result) => { toast.success(`Makale #${result.id} oluşturuldu.`); setTitle(""); setSummary(""); setContent(""); }, onError: (error) => toast.error(error.message) });
  if (user?.role !== "admin") return <DashboardLayout><div className="panel p-10 text-center"><h1 className="font-display text-3xl uppercase text-white">Yetki gerekli</h1><p className="mt-2 text-sm text-muted-foreground">Bu ekran yalnızca yönetici rolüne açıktır.</p></div></DashboardLayout>;
  return <DashboardLayout><div className="mx-auto max-w-4xl space-y-6"><div className="flex items-end justify-between border-b border-border pb-5"><div><div className="kicker mb-2">/ knowledge operations</div><h1 className="font-display text-4xl uppercase text-white">Wiki yayın masası</h1><p className="mt-2 text-sm text-muted-foreground">Yeni makale oluştur, içerik gövdesini temizle ve taslak/yayın durumunu kaydet.</p></div><BookOpen className="text-primary" /></div><form onSubmit={(event) => { event.preventDefault(); create.mutate({ categoryId: Number(categoryId), title, summary, content, status: "published" }); }} className="panel space-y-4 p-5"><label className="grid gap-2 text-xs text-muted-foreground">Kategori ID<input value={categoryId} onChange={(event) => setCategoryId(event.target.value)} type="number" min="1" required aria-label="Wiki kategori ID" className="rounded-md border border-border bg-black/25 px-3 py-2.5 text-white" /></label><label className="grid gap-2 text-xs text-muted-foreground">Başlık<input value={title} onChange={(event) => setTitle(event.target.value)} minLength={3} maxLength={180} required className="rounded-md border border-border bg-black/25 px-3 py-2.5 text-white" /></label><label className="grid gap-2 text-xs text-muted-foreground">Özet<textarea value={summary} onChange={(event) => setSummary(event.target.value)} minLength={3} maxLength={500} required rows={3} className="rounded-md border border-border bg-black/25 px-3 py-2.5 text-white" /></label><label className="grid gap-2 text-xs text-muted-foreground">İçerik<textarea value={content} onChange={(event) => setContent(event.target.value)} minLength={20} maxLength={50000} required rows={14} className="rounded-md border border-border bg-black/25 px-3 py-2.5 font-mono text-sm text-white" /></label><div className="flex items-center justify-between"><Link href="/admin" className="text-xs text-muted-foreground hover:text-primary">← Yönetim merkezine dön</Link><Button disabled={create.isPending} type="submit" className="gap-2 bg-primary text-primary-foreground"><Save size={15} />{create.isPending ? "Yayınlanıyor" : "Yayınla"}</Button></div></form></div></DashboardLayout>;
}
