import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import CommunityLayout from "./components/CommunityLayout";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Forums from "./pages/Forums";
import Thread from "./pages/Thread";
import Members from "./pages/Members";
import SearchPage from "./pages/SearchPage";
import Explore from "./pages/Explore";
import Admin from "./pages/Admin";
import Profile from "./pages/Profile";
import Notifications from "./pages/Notifications";
import Messages from "./pages/Messages";
import Settings from "./pages/Settings";
import Announcement from "./pages/Announcement";
import WikiAdmin from "./pages/WikiAdmin";

function PublicRoutes() {
  return <CommunityLayout><Switch><Route path="/" component={Home} /><Route path="/forums/:id" component={Forums} /><Route path="/forums" component={Forums} /><Route path="/threads/:id" component={Thread} /><Route path="/members/:id" component={Profile} /><Route path="/members" component={Members} /><Route path="/profile" component={Profile} /><Route path="/notifications" component={Notifications} /><Route path="/announcements/:id" component={Announcement} /><Route path="/messages" component={Messages} /><Route path="/settings" component={Settings} /><Route path="/search" component={SearchPage} /><Route path="/wiki/:id" component={Explore} /><Route path="/wiki" component={Explore} /><Route path="/events" component={Explore} /><Route path="/ctf/:id" component={Explore} /><Route path="/ctf" component={Explore} /><Route path="/leaderboard" component={Explore} /><Route path="/404" component={NotFound} /><Route component={NotFound} /></Switch></CommunityLayout>;
}

function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark"><TooltipProvider><Toaster theme="dark" /><Switch><Route path="/admin/wiki" component={WikiAdmin} /><Route path="/admin" component={Admin} /><Route component={PublicRoutes} /></Switch></TooltipProvider></ThemeProvider></ErrorBoundary>;
}

export default App;
