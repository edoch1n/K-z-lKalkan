import { useState } from "react";
import { Bell, BookOpen, ChevronDown, Flag, Home, LogIn, Menu, MessageSquare, Search, Trophy, Users, X, Zap } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";

const navItems = [
  { href: "/", label: "Ana Sayfa", icon: Home },
  { href: "/forums", label: "Forumlar", icon: MessageSquare },
  { href: "/members", label: "Üyeler", icon: Users },
  { href: "/ctf", label: "CTF", icon: Flag },
  { href: "/wiki", label: "Wiki", icon: BookOpen },
  { href: "/events", label: "Etkinlikler", icon: Zap },
  { href: "/leaderboard", label: "Liderlik Tablosu", icon: Trophy },
];

function isActivePath(location: string, href: string) {
  return href === "/" ? location === "/" : location === href || location.startsWith(`${href}/`);
}

function Brand() {
  return (
    <Link href="/" className="flex min-w-0 items-center gap-2.5" aria-label="TURKWOLFTEAM ana sayfa">
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded border border-accent/60 bg-[#101010] text-accent">
        <span className="font-display text-lg font-bold">W</span>
      </span>
      <span className="min-w-0">
        <span className="block truncate font-display text-base font-bold tracking-[.1em] text-white">TURKWOLFTEAM</span>
        <span className="hidden font-mono text-[8px] uppercase tracking-[.15em] text-muted-foreground sm:block">Türk teknoloji topluluğu</span>
      </span>
    </Link>
  );
}

function NavList({ location, onNavigate }: { location: string; onNavigate?: () => void }) {
  return (
    <nav className="grid gap-0.5" aria-label="Ana navigasyon">
      {navItems.map((item) => {
        const Icon = item.icon;
        const active = isActivePath(location, item.href);
        return (
          <Link key={item.href} href={item.href} onClick={onNavigate} className={`flex items-center gap-2.5 rounded px-2.5 py-2 text-[12px] transition-colors ${active ? "bg-accent/10 text-accent" : "text-muted-foreground hover:bg-white/[.04] hover:text-foreground"}`}>
            <Icon size={15} strokeWidth={1.8} />
            <span>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

function LiveSidebar() {
  const overview = trpc.home.overview.useQuery();
  return (
    <aside className="hidden min-w-0 lg:block">
      <div className="sticky top-[76px] space-y-4">
        <section className="sidebar-section">
          <h2 className="sidebar-heading">Son Konular</h2>
          <div className="sidebar-list">
            {overview.data?.latestThreads?.length ? overview.data.latestThreads.slice(0, 5).map((thread) => (
              <Link key={thread.id} href={`/threads/${thread.id}`} className="sidebar-item">
                <strong>{thread.title}</strong>
                <span>{thread.authorName} · {thread.replyCount} yanıt</span>
              </Link>
            )) : <p className="py-3 text-xs text-muted-foreground">Son konular yükleniyor...</p>}
          </div>
        </section>
        <section className="sidebar-section">
          <h2 className="sidebar-heading">Aktif Üyeler</h2>
          <div className="sidebar-list">
            {overview.data?.activeMembers?.length ? overview.data.activeMembers.map((member) => (
              <Link key={member.id} href={`/members/${member.id}`} className="sidebar-item flex items-center gap-2">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-accent/40 bg-accent/10 font-mono text-[9px] text-accent">{(member.name || "Ü").slice(0, 2).toUpperCase()}</span>
                <span className="min-w-0"><strong className="truncate">{member.name}</strong><span>çevrimiçi</span></span>
              </Link>
            )) : <p className="py-3 text-xs text-muted-foreground">Aktif üyeler yükleniyor...</p>}
          </div>
        </section>
        <section className="sidebar-section">
          <h2 className="sidebar-heading">Forum İstatistikleri</h2>
          <div className="space-y-2 p-3 font-mono text-[10px]">
            <div className="flex justify-between"><span className="text-muted-foreground">Üye</span><span className="text-foreground">{overview.data?.stats.members ?? "—"}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Konu</span><span className="text-foreground">{overview.data?.stats.threads ?? "—"}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Mesaj</span><span className="text-foreground">{overview.data?.stats.posts ?? "—"}</span></div>
          </div>
        </section>
      </div>
    </aside>
  );
}

export default function CommunityLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, loading, isAuthenticated, logout } = useAuth();
  const notifications = trpc.notifications.list.useQuery(undefined, { enabled: Boolean(isAuthenticated) });
  const unread = notifications.data?.unread ?? 0;
  const displayName = user?.displayName || user?.name || "Profil";

  return (
    <div className="app-shell min-h-screen">
      <header className="sticky top-0 z-40 border-b border-border bg-[#101010]">
        <div className="mx-auto flex h-[58px] max-w-[1380px] items-center gap-3 px-3 sm:px-5 lg:px-6">
          <button type="button" className="rounded p-2 text-muted-foreground hover:bg-white/[.05] hover:text-white lg:hidden" onClick={() => setMobileOpen((value) => !value)} aria-label="Menüyü aç/kapat" aria-expanded={mobileOpen}>
            {mobileOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
          <Brand />
          <div className="ml-auto flex items-center gap-1.5">
            <Link href="/search" className="rounded border border-transparent p-2 text-muted-foreground hover:border-border hover:text-accent" aria-label="Arama"><Search size={17} /></Link>
            {isAuthenticated && <Link href="/notifications" className="relative rounded border border-transparent p-2 text-muted-foreground hover:border-border hover:text-accent" aria-label="Bildirimler"><Bell size={17} />{unread > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-accent px-1 font-mono text-[9px] text-white">{unread > 9 ? "9+" : unread}</span>}</Link>}
            {isAuthenticated && <Link href="/messages" className="hidden rounded border border-transparent p-2 text-muted-foreground hover:border-border hover:text-accent sm:block" aria-label="Mesajlar"><MessageSquare size={17} /></Link>}
            {loading ? <span className="h-7 w-7 animate-pulse rounded-full bg-white/[.06]" /> : isAuthenticated ? <div className="hidden items-center gap-2 border-l border-border pl-2 sm:flex"><Link href="/profile" className="flex items-center gap-2 text-xs text-muted-foreground hover:text-white"><span className="grid h-7 w-7 place-items-center rounded-full border border-accent/50 bg-accent/10 font-mono text-[9px] text-accent">{displayName.slice(0, 2).toUpperCase()}</span><span className="max-w-24 truncate">{displayName}</span></Link><button type="button" onClick={() => logout()} className="p-1 text-muted-foreground hover:text-destructive" aria-label="Çıkış yap"><ChevronDown size={14} /></button></div> : <Button size="sm" onClick={() => startLogin()} className="h-8 gap-1.5 bg-accent px-3 text-xs text-white hover:bg-accent/85"><LogIn size={14} /> Giriş</Button>}
          </div>
        </div>
      </header>

      {mobileOpen && <div className="fixed inset-x-0 top-[58px] z-30 border-b border-border bg-[#101010] p-3 shadow-xl lg:hidden"><NavList location={location} onNavigate={() => setMobileOpen(false)} /><div className="mt-2 border-t border-border pt-2"><Link href="/messages" onClick={() => setMobileOpen(false)} className="flex items-center gap-2.5 rounded px-2.5 py-2 text-[12px] text-muted-foreground hover:bg-white/[.04] hover:text-white"><MessageSquare size={15} /> Mesajlar</Link>{isAuthenticated && <Link href="/profile" onClick={() => setMobileOpen(false)} className="flex items-center gap-2.5 rounded px-2.5 py-2 text-[12px] text-muted-foreground hover:bg-white/[.04] hover:text-white"><Users size={15} /> Profil</Link>}<Link href="/settings" onClick={() => setMobileOpen(false)} className="flex items-center gap-2.5 rounded px-2.5 py-2 text-[12px] text-muted-foreground hover:bg-white/[.04] hover:text-white">Ayarlar</Link>{isAuthenticated && <button type="button" onClick={() => { setMobileOpen(false); logout(); }} className="flex w-full items-center gap-2.5 rounded px-2.5 py-2 text-left text-[12px] text-destructive hover:bg-destructive/10">Çıkış yap</button>}</div></div>}

      <div className="mx-auto grid max-w-[1380px] grid-cols-1 gap-5 px-3 py-5 sm:px-5 lg:grid-cols-[190px_minmax(0,1fr)_250px] lg:px-6">
        <aside className="hidden min-w-0 lg:block"><div className="sticky top-[76px] space-y-4"><section><h2 className="mb-2 px-2 font-mono text-[10px] uppercase tracking-[.12em] text-muted-foreground">Gezinme</h2><NavList location={location} /></section><section className="sidebar-section"><h2 className="sidebar-heading">Topluluk</h2><div className="space-y-2 p-3 text-[11px] leading-5 text-muted-foreground">Türk teknoloji, yazılım ve siber güvenlik topluluğu. Bilgiyi paylaş, birlikte üret.</div></section></div></aside>
        <main className="min-w-0">{children}</main>
        <LiveSidebar />
      </div>
      <footer className="mx-auto max-w-[1380px] border-t border-border px-3 py-5 text-center font-mono text-[9px] uppercase tracking-[.14em] text-muted-foreground/70 sm:px-5 lg:px-6">TURKWOLFTEAM · ENTER THE WOLF NETWORK</footer>
    </div>
  );
}
