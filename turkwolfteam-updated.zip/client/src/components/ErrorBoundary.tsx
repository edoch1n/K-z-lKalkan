import { AlertTriangle, Home, RotateCcw } from "lucide-react";
import { Component, ReactNode } from "react";

interface Props { children: ReactNode; }
interface State { hasError: boolean; }

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };
  static getDerivedStateFromError(): State { return { hasError: true }; }
  componentDidCatch(error: Error) { console.error("[TURKWOLFTEAM] UI boundary caught error", error); }
  render() {
    if (!this.state.hasError) return this.props.children;
    return <main className="grid min-h-screen place-items-center bg-background px-6 py-12 text-foreground"><section role="alert" className="panel w-full max-w-xl p-8 text-center"><AlertTriangle className="mx-auto mb-5 text-destructive" size={42} /><div className="kicker mb-2">/ signal interrupted · 500</div><h1 className="font-display text-4xl uppercase text-white">Bir şey ters gitti</h1><p className="mx-auto mt-3 max-w-md text-sm leading-6 text-muted-foreground">Bu ekran beklenmeyen bir hatayla karşılaştı. Teknik ayrıntılar güvenlik için gösterilmiyor. Sayfayı yenileyin veya merkeze dönün.</p><div className="mt-6 flex flex-wrap justify-center gap-3"><button onClick={() => window.location.reload()} className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary/85"><RotateCcw size={15} /> Yenile</button><button onClick={() => { window.location.href = "/"; }} className="inline-flex items-center gap-2 rounded-md border border-border px-4 py-2.5 text-sm text-foreground hover:border-primary/60 hover:text-primary"><Home size={15} /> Merkeze dön</button></div></section></main>;
  }
}
