# TURKWOLFTEAM

TURKWOLFTEAM, Türkçe öncelikli, güvenlik odaklı bir topluluk forumu ve siber operasyon platformudur. Uygulama React 19, Tailwind CSS 4, Express, tRPC 11, Drizzle ORM ve Manus OAuth üzerinde çalışır.

## Modüller

| Alan | Kapsam |
| --- | --- |
| Topluluk | Kategori/forum hiyerarşisi, sayfalanmış konular, yanıtlar, quote, mention, reaksiyon, sabitleme ve kilitleme |
| Kimlik | Manus OAuth, güvenli oturum, kullanıcı profilleri, rank/achievement ve sunucu tarafı RBAC |
| İletişim | Kalıcı bildirim merkezi, okunma durumu, özel mesajlar, arama, engelleme ve raporlama |
| Moderasyon | Rapor kuyruğu, kullanıcı cezaları, içerik işlemleri, moderatör notları ve hash-zincirli audit kayıtları |
| Bilgi/etkinlik | Kontrollü wiki yayınlama ve revizyon geçmişi, etkinlik katılımı/ayrılma ve geri sayım için veri modeli |
| CTF | Challenge, ipucu, puan, solve takibi, write-up modeli ve yalnızca sunucuda SHA-256 flag doğrulaması |
| Yönetim | Ayrı `/admin` rotası; canlı metrikler, raporlar, RBAC, içerik moderasyonu ve modül kontrol yüzeyi |

## Geliştirme

```bash
pnpm install
pnpm check
pnpm test
pnpm build
pnpm dev
```

Veritabanı şeması `drizzle/schema.ts` içindedir. Şema değişikliğinde `pnpm drizzle-kit generate` ile migration üretin, oluşan SQL'i inceleyin ve proje yönetim ekranındaki güvenli SQL çalıştırma akışıyla uygulayın. Veritabanı zaman damgaları UTC tabanlı tutulur; arayüz yerel saat dilimine dönüştürür.

## Güvenlik notları

Sunucu prosedürleri `protectedProcedure`, `permissionProcedure` ve `adminProcedure` ile korunur. Kullanıcı girdileri Zod ile sınırlandırılır; yüksek riskli mutation'lar kullanıcı bazlı rate limit uygular. Post soft-delete ile geri alınabilir biçimde gizlenir. Kritik moderasyon, rol, rank, achievement ve duyuru işlemleri değiştirilemez audit kaydı üretir.

CTF flag değeri hiçbir istemci yanıtına, bundle'a veya görünür HTML'e gönderilmez. Challenge kaydı yalnızca hash taşır; gelen flag sunucuda SHA-256 ile hash'lenir ve sabit zamanlı karşılaştırılır. Aynı challenge için aynı cevap hash'i yeniden kaydedilmez.

Avatar, wiki eki ve CTF eki yüklemeleri nesne depolamasına gider. Dosya boyutu, MIME türü, uzantı ve magic-byte imzası denetlenir; isimler normalize edilir. Storage metadata sahibi ve görünürlük seviyesiyle veritabanında tutulur. İmzalı indirme URL'si yalnızca yetkili kullanıcıya döndürülür.

Sahip/yönetici uyarıları yerleşik bildirim kanalına gönderilir. Kritik raporlar, ağır moderasyon olayları ve kritik duyurular için bildirim gönderimi başarısız olsa bile ana işlem güvenli biçimde devam eder ve sunucu log'una kontrollü uyarı yazılır.

## Rotalar

Public/community: `/`, `/forums`, `/forums/:id`, `/threads/:id`, `/members`, `/members/:id`, `/search`, `/wiki`, `/events`, `/ctf`, `/leaderboard`, `/notifications`, `/messages`, `/settings`, `/announcements/:id`.

Admin: `/admin`. Admin arayüzü sunucu tarafındaki rol kontrolüyle başlar; istemci görünürlüğü tek başına güvenlik sınırı değildir.

## QA

Kritik testler `server/` altında bulunur. `pnpm check`, `pnpm test` ve `pnpm build` son doğrulama akışının parçalarıdır. Görsel doğrulama public modüller, mobil düzen ve `/admin` için yapılmıştır. Dev server'ın başlangıçta gösterdiği `Missing session cookie` mesajı anonim ilk yüklemede beklenen OAuth davranışıdır; giriş yapılmış akışta session bearer ile RPC çağrıları başarılıdır.

Autoscale çalışma modelinde rate-limit bucket'ları süreç belleğindedir. Çoklu instance ve kalıcı kötüye kullanım önleme ihtiyacı için üretimde Redis veya veritabanı tabanlı dağıtık limiter eklenmelidir. Bu sürüm uygulama katmanında temel spam ve burst kontrolünü sağlar.

## Hostinger dağıtımı

Proje mevcut Express + Vite üretim modelini korur ve MySQL/MariaDB ile çalışır. Hostinger üzerinde bir MySQL veritabanı oluşturun, `.env.example` dosyasını `.env` olarak kopyalayın ve yalnızca gerçek hosting değerlerini girin. `DATABASE_URL`, `JWT_SECRET`, OAuth değişkenleri ve gerekiyorsa object-storage değişkenleri production değerleri olmalıdır; gerçek secret değerleri Git'e eklenmemelidir.

```bash
pnpm install --frozen-lockfile
pnpm db:push
pnpm build
NODE_ENV=production pnpm start
```

Reverse proxy veya Hostinger uygulama ayarlarında `PORT` ve `APP_URL` tanımlanmalı, HTTPS aktif edilmelidir. Production'da Manus sandbox URL'leri, localhost API adresleri veya yerel mutlak dosya yolları kullanılmamalıdır. Upload akışını etkinleştirecekseniz `BUILT_IN_FORGE_API_URL` ve `BUILT_IN_FORGE_API_KEY` yerine Hostinger uyumlu nesne depolama/proxy sağlayıcısını yapılandırın; bu değişkenler boş bırakılırsa yükleme özelliğini kapalı tutun.

## Güncel UI yaklaşımı

Public topluluk kabuğu kompakt forum indeksine göre yenilendi. Header ve mobil menü küçültüldü, forum ana sayfası canlı kategori/forum satırlarıyla düzenlendi, forum indeksinde konu/yanıt/görüntülenme/son mesaj sütunları eklendi, konu görünümü masaüstünde iki kolonlu ve mobilde tek kolonlu hale getirildi. Üye ve profil ekranları büyük dashboard kartları yerine forum tipi yoğun listeler ve sekmeler kullanır. Palet koyu gri yüzeyler, açık gri tipografi ve kontrollü cyan vurgudan oluşur; sürekli glitch, scanline ve ağır glow efektleri kaldırılmıştır.
